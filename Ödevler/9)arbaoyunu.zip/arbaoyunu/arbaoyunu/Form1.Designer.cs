﻿namespace arbaoyunu
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.yol = new System.Windows.Forms.PictureBox();
            this.arac1 = new System.Windows.Forms.PictureBox();
            this.arac2 = new System.Windows.Forms.PictureBox();
            this.araba = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.yol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arac1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arac2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.araba)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            // 
            // yol
            // 
            this.yol.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("yol.BackgroundImage")));
            this.yol.Location = new System.Drawing.Point(50, 3);
            this.yol.Name = "yol";
            this.yol.Size = new System.Drawing.Size(398, 621);
            this.yol.TabIndex = 0;
            this.yol.TabStop = false;
            // 
            // arac1
            // 
            this.arac1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("arac1.BackgroundImage")));
            this.arac1.Location = new System.Drawing.Point(64, 123);
            this.arac1.Name = "arac1";
            this.arac1.Size = new System.Drawing.Size(78, 181);
            this.arac1.TabIndex = 3;
            this.arac1.TabStop = false;
            // 
            // arac2
            // 
            this.arac2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("arac2.BackgroundImage")));
            this.arac2.Location = new System.Drawing.Point(336, 89);
            this.arac2.Name = "arac2";
            this.arac2.Size = new System.Drawing.Size(83, 182);
            this.arac2.TabIndex = 4;
            this.arac2.TabStop = false;
            // 
            // araba
            // 
            this.araba.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("araba.BackgroundImage")));
            this.araba.Location = new System.Drawing.Point(205, 501);
            this.araba.Name = "araba";
            this.araba.Size = new System.Drawing.Size(83, 123);
            this.araba.TabIndex = 5;
            this.araba.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.araba);
            this.panel1.Controls.Add(this.arac2);
            this.panel1.Controls.Add(this.arac1);
            this.panel1.Controls.Add(this.yol);
            this.panel1.Location = new System.Drawing.Point(-25, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(598, 653);
            this.panel1.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(446, 636);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Araba Oyun";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.yol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arac1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arac2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.araba)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox yol;
        private System.Windows.Forms.PictureBox arac1;
        private System.Windows.Forms.PictureBox arac2;
        private System.Windows.Forms.PictureBox araba;
        private System.Windows.Forms.Panel panel1;
    }
}

