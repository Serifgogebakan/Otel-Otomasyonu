﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arbaoyunu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            basla();

        }

        int yol_hizi = 5;
        int araba_hiz = 5;
        bool sol_yon = false;
        bool sag_yon = false;
        int diger_araba_hizi = 5;
        Random rnd = new Random();

        private void basla(){

            //Arabanın ve yolun aşağıya doğru kayma hızı 
            diger_araba_hizi = 5;
            yol_hizi = 5;

            //Arabamızın koordinatı
            araba.Left = 166;
            araba.Top = 293;

            //Kontrol tuşlarını yasif yapıyoruz
            sol_yon = false;
            sag_yon = false;

            //Diğer arabaların koordinatları
            arac1.Left = 66;
            arac1.Top = -120;
            arac2.Left = 294;
            arac2.Top = -185;

            //Zeminde hareket edecek olan yolun koordinatı
            yol.Left = -3;
            yol.Top = -222;
       
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e){


            //Yolun yukardan aşağı hareketi ve tekrar başa dönme kontrolü 
            yol.Top += yol_hizi;   
            if (yol.Top > 630) yol.Top = -630;
           

            //Yön tuşları ile arabanın hareketi 
            if (sol_yon)araba.Left -= araba_hiz;
            if (sag_yon) araba.Left += araba_hiz;
            if (araba.Left < 1) { sol_yon = false; }
            else if (araba.Left + araba.Width > 380) { sag_yon = false; }

            //Diğer arabaların aşağı doğru hareketli ve rastgele bir şekilde gelmesi
            arac1.Top += diger_araba_hizi;
            arac2.Top += diger_araba_hizi;
           
        
        }

       

        private void Form1_KeyDown(object sender, KeyEventArgs e)  //Tuş basma olayında sağa veya sola hareketin kontrolü
        {
           
            if (e.KeyCode == Keys.Left && araba.Left > 0) sol_yon = true;

            if (e.KeyCode == Keys.Right && araba.Left + araba.Width < panel1.Width) sag_yon = true;
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Left) sol_yon = false;
            if (e.KeyCode == Keys.Right) sag_yon = false;
        }

        
    }
}