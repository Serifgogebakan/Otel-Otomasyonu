﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kısım4ornek3 {
    // Motor sınıfı
    class Motor{

        public int Guc { get; set; }  // Motor gücü (beygir gücü cinsinden)
        public string Tip { get; set; }  // Motor tipi (örnek Dizel, Elektrikli v.b)

        // Motor sınıfı yapıcı metot
        public Motor(int guc, string tip){
            Guc = guc;
            Tip = tip;
        }

        // Motor bilgilerini yazdırma metodu
        public void MotorBilgisi(){
            Console.WriteLine($"Motor Gücü: {Guc} HP, Tip: {Tip}");
        }
    }

    // Otomobil sınıfı
    class Otomobil{

        public string Marka { get; set; }  // Otomobilin markası
        public Motor Motor { get; set; }  // Otomobilin motoru

        // Otomobil sınıfı yapıcı metot
        public Otomobil(string marka){
            Marka = marka;
        }

        // Otomobil için motor oluşturma metodu
        public void MotorOlustur(int guc, string tip){
            Motor = new Motor(guc, tip);  // Motor nesnesi oluşturulur ve otomobile atanır
        }




        // Otomobil bilgilerini yazdırma metodu
        public void EkranaYazdir(){
            Console.WriteLine($"Otomobil Markası: {Marka}");
            if (Motor != null){
                Console.WriteLine("Motor Bilgileri:");
                Motor.MotorBilgisi();
            } else{
                Console.WriteLine("Otomobilde motor yok.");
            }
        }
    }





    // Program sınıfı (Main metodu içerir)
    class Program{
        static void Main(string[] args){
            // Otomobil nesnesi oluşturuluyor
            Otomobil otomobil = new Otomobil("TOGG");

            // Otomobil için motor oluşturuluyor
            otomobil.MotorOlustur(200, "Elektirikli");

            // Otomobil ve motor bilgileri ekrana yazdırılır
            otomobil.EkranaYazdir();
            Console.ReadLine();
        }
    }

}
