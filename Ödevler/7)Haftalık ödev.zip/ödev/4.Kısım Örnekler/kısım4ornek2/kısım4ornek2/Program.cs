﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım4ornek2{


    // İşlemci sınıfı
    class Islemci{
        public int Cekirdek { get; set; }  // İşlemcinin çekirdek sayısı
        public double Frekans { get; set; }  // İşlemcinin frekansı (GHz cinsinden)

        // İşlemci sınıfı yapıcı metot
        public Islemci(int cekirdek, double frekans){
            Cekirdek = cekirdek;
            Frekans = frekans;
        }

        // İşlemci bilgilerini yazdırma metodu
        public void IslemciBilgisi(){
            Console.WriteLine($"Çekirdek Sayısı: {Cekirdek}, Frekans: {Frekans} GHz");
        }
    }



    // Bilgisayar sınıfı
    class Bilgisayar{
        public string Model { get; set; }  // Bilgisayarın modeli
        public Islemci Islemci { get; set; }  // Bilgisayarın işlemcisi

        // Bilgisayar sınıfı yapıcı metot
        public Bilgisayar(string model){
            Model = model;
        }

        // Bilgisayar için işlemci oluşturma metodu
        public void IslemciOlustur(int cekirdek, double frekans){
            Islemci = new Islemci(cekirdek, frekans);  // İşlemci nesnesi oluşturulur ve bilgisayara atanır
        }



        // Bilgisayar bilgilerini yazdırma metodu
        public void EkranaYazdir(){

            Console.WriteLine($"Bilgisayar Modeli: {Model}");
            if (Islemci != null){
                Console.WriteLine("İşlemci Bilgileri:");
                Islemci.IslemciBilgisi();
            } else {
                Console.WriteLine("Bilgisayarda işlemci yok.");
            }
        }


    }




    class Program{
        static void Main(string[] args){

            // Bilgisayar nesnesi oluşturuluyor
            Bilgisayar bilgisayar = new Bilgisayar("Monster Abra");

            // Bilgisayar için işlemci oluşturuluyor
            bilgisayar.IslemciOlustur(8, 3.5);

            // Bilgisayar ve işlemci bilgileri ekrana yazdırılıyor
            bilgisayar.EkranaYazdir();
            Console.ReadLine();

        } 
    }



}
