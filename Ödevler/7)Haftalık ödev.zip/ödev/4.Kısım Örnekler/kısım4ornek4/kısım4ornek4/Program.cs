﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım4ornek4 {



    // Öğrenci sınıfı
    class Ogrenci{

        public string Ad { get; set; }  // Öğrencinin adı
        public int Yas { get; set; }  // Öğrencinin yaşı

        // Öğrenci sınıfı yapıcı metot
        public Ogrenci(string ad, int yas) {
            Ad = ad;
            Yas = yas;
        }

        // Öğrenci bilgilerini yazdırma metodu
        public void OgrenciBilgisi(){
            Console.WriteLine($"Öğrenci Adı: {Ad}, Yaş: {Yas}");
        }
    }



    // Okul sınıfı
    class Okul{
        public string Ad { get; set; }  // Okulun adı
        public List<Ogrenci> Ogrenciler { get; set; }  // Okulun öğrencileri

        // Okul sınıfı yapıcı metot
        public Okul(string ad){
            Ad = ad;
            Ogrenciler = new List<Ogrenci>();  // Öğrenciler listesini başlat
        }

        // Okula öğrenci oluşturma ve ekleme metodu
        public void OgrenciOlustur(string ad, int yas){
            Ogrenci ogrenci = new Ogrenci(ad, yas);  // Yeni öğrenci oluşturulur
            Ogrenciler.Add(ogrenci);  // Öğrenci listeye eklenir
        }





        // Okul bilgilerini yazdırma metodu
        public void EkranaYazdir(){

            Console.WriteLine($"Okul Adı: {Ad}");
            Console.WriteLine("Öğrenciler:");
            foreach (Ogrenci ogrenci in Ogrenciler){

                ogrenci.OgrenciBilgisi();
            }
        }
    }





    class Program{
        static void Main(string[] args){
            // Okul nesnesi oluşturur
            Okul okul = new Okul("Fırat ünüversitesi");

            // Okula öğrenciler ekler
            okul.OgrenciOlustur("XXX xxx", 18);
          

            // Okul ve öğrencilerin bilgileri ekrana yazdırılır
            okul.EkranaYazdir();
            Console.ReadLine();
        }
    }




}
