﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım3ornek4{
    // Kitap sınıfı
    class Kitap{
        public string Baslik { get; set; }  // Kitabın başlığı
        public string Yazar { get; set; }  // Kitabın yazarı

        // Kitap sınıfı yapıcı metot
        public Kitap(string baslik, string yazar){  
            Baslik = baslik;
            Yazar = yazar;
        }



        // Kitap bilgilerini yazdırma metodu
        public void EkranaYazdir(){
            Console.WriteLine($"Başlık: {Baslik}, Yazar: {Yazar}");
        }
    }



    // Kütüphane sınıfı
       class Kutuphane{
        public string Ad { get; set; }  // Kütüphanenin adı
        public List<Kitap> Kitaplar { get; set; }  // Kütüphanedeki kitapların listesi

        // Kütüphane sınıfı yapıcı metot
        public Kutuphane(string ad){
            Ad = ad;
            Kitaplar = new List<Kitap>();  // Kitaplar listesini başlat
        }

        // Kütüphaneye kitap ekleme metodu
        public void KitapEkle(Kitap kitap){
            Kitaplar.Add(kitap);  // Yeni kitap listeye eklenir
        }




        // Kütüphane bilgilerini yazdırma metodu
        public void EkranaYazdir(){
            Console.WriteLine($"Kütüphane Adı: {Ad}");
            Console.WriteLine("Kitaplar:");
            foreach (Kitap kitap in Kitaplar){
                kitap.EkranaYazdir();
            }
        }
    }





}
