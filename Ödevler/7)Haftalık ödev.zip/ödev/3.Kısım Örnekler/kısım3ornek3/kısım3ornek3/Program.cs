﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım3ornek3{

    // Çalışan sınıfı
    class Calisan{
        public string Ad { get; set; }  // Çalışanın adı
        public string Pozisyon { get; set; }  // Çalışanın pozisyonu

        // Çalışan sınıfı yapıcı metot
        public Calisan(string ad, string pozisyon){
            Ad = ad;
            Pozisyon = pozisyon;
        }

        // Çalışan bilgilerini yazdırma metodu
        public void CalisanBilgisi(){
            Console.WriteLine($"Çalışan Adı: {Ad}, Pozisyon: {Pozisyon}");
        }
    }




    // Şirket sınıfı
    class Sirket{
        public string Ad { get; set; }  // Şirketin adı
        public List<Calisan> Calisanlar { get; set; }  // Şirketin çalışanlarının listesi

        // Şirket sınıfı yapıcı metot
        public Sirket(string ad){
            Ad = ad;
            Calisanlar = new List<Calisan>();  // Çalışanlar listesini başlat
        }

        // Şirkete çalışan ekleme metodu
        public void CalisanEkle(Calisan calisan){
            Calisanlar.Add(calisan);  // Yeni çalışan listeye eklenir
        }




        // Şirket bilgilerini yazdırma metodu
        public void EkranaYazdir(){
            Console.WriteLine($"Şirket Adı: {Ad}");
            Console.WriteLine("Çalışanlar:");
            foreach (Calisan calisan in Calisanlar)
            {
                calisan.CalisanBilgisi();
            }
        }
    }






}
