﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım3ornek2{

    // Oda sınıfı
    class Oda{
        public double Boyut { get; set; }  // Odanın boyutu 
        public string Tip { get; set; }  // Odanın tipi 

        // Oda sınıfı yapıcı metot
        public Oda(double boyut, string tip){

            Boyut = boyut;
            Tip = tip;
        }

        // Oda bilgilerini yazdıran metot
        public void EkranaYazdir(){
            Console.WriteLine($"Oda Tipi: {Tip}, Boyut: {Boyut} m²");

        }
    }



    // Ev sınıfı
    class Ev{
        public string Ad { get; set; }  // Evin adı örneğin apartman
        public List<Oda> Odalar { get; set; }  // Evin odalarının listesi

        // Ev sınıfı yapıcı metot
        public Ev(string ad){
            Ad = ad;
            Odalar = new List<Oda>();  // Odalar listesi başlatılır
        }
        // Eve oda ekleme metodu
        public void OdaEkle(Oda oda){
            Odalar.Add(oda);  // Yeni oda listeye eklenir
        }

        // Ev bilgilerini yazdıran metod
        public void EkranaYazdir(){

            Console.WriteLine($"Ev Adı: {Ad}");
        }
    }





}
