﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım2ornek3{

    // Kitap sınıfı
    class Kitap{
        public string Baslik { get; set; }  // Kitabın başlığı
        public DateTime YayinTarihi { get; set; }  // Kitabın yayın tarihi
        public Yazar Yazar { get; set; }  // Kitabın yazarı

        // Kitap sınıfı yapıcı metot
        public Kitap(string baslik, DateTime yayinTarihi){
            Baslik = baslik;
            YayinTarihi = yayinTarihi;
        }

        // Kitabın yazarı atama metodu
        public void YazarAtama(Yazar yazar){
            Yazar = yazar;
        }
    }



    // Yazar sınıfı
    class Yazar{
        public string Ad { get; set; }  // Yazarın adı
        public string Ulke { get; set; }  // Yazarın ülkesi
        public List<Kitap> Kitaplar { get; set; }  // Yazarın kitapları

        // Yazar sınıfı yapıcı metot
        public Yazar(string ad, string ulke){
            Ad = ad;
            Ulke = ulke;
            Kitaplar = new List<Kitap>();  // Kitaplar listesi başlatılır
        }

        // Yazarın kitaplarına kitap ekleme metodu
        public void KitapEkle(Kitap kitap){
            Kitaplar.Add(kitap);
            kitap.YazarAtama(this);  // Kitabın yazarı olarak bu yazar atanır
        }
    }



}
