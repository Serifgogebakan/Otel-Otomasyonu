﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kısım2ornek4{

    // Çalışan sınıfı
    class Calisan{
        public string Baslik { get; set; }  // Çalışanın başlığı
        public DateTime YayinTarihi { get; set; }  // Çalışanın işe başlama tarihi
        public Sirket Sirket { get; set; }  // Çalışanın bağlı olduğu şirket

        // Çalışan sınıfı yapıcı metot
        public Calisan(string baslik, DateTime yayinTarihi){
            Baslik = baslik;
            YayinTarihi = yayinTarihi;
        }

        // Çalışana şirket atama metodu
        public void SirketAta(Sirket sirket){
            Sirket = sirket;
        }

        // Çalışan bilgilerini yazdırma metodu
        public void EkranaYazdir(){

            Console.WriteLine($"Başlık: {Baslik}, Yayın Tarihi: {YayinTarihi.ToString("dd.MM.yyyy")}, Şirket: {Sirket.Ad}");
        }
    }




    // Şirket sınıfı
    class Sirket{
        public string Ad { get; set; }  // Şirketin adı
        public string Konum { get; set; }  // Şirketin konumu
        public List<Calisan> Calisanlar { get; set; }  // Şirketin çalışanlarının listesi

        // Şirket sınıfı yapıcı metot
        public Sirket(string ad, string konum){
            Ad = ad;
            Konum = konum;
            Calisanlar = new List<Calisan>();  // Çalışanlar listesi başlatılır
        }

        // Şirkete çalışan ekleme metodu
        public void CalisanEkle(Calisan calisan){

            Calisanlar.Add(calisan);
            calisan.SirketAta(this);  // Çalışanın şirketi olarak bu şirket atanır
        }
    }


 



}
