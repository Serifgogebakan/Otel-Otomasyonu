﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım2ornek5
{
    // Çocuk sınıfı
    class Cocuk
    {
        public string Ad { get; set; }  // Çocuğun adı
        public int Yas { get; set; }  // Çocuğun yaşı
        public Ebeveyn Ebeveyn { get; set; }  // Çocuğun bağlı olduğu ebeveyn

        // Çocuk sınıfı yapıcı metot
        public Cocuk(string ad, int yas)
        {
            Ad = ad;
            Yas = yas;
        }
        // Ebeveyn atama metodu
        public void EbeveynAta(Ebeveyn ebeveyn)
        {
            Ebeveyn = ebeveyn;
        }
    }

    // Ebeveyn sınıfı
    class Ebeveyn
    {
        public string Ad { get; set; }  // Ebeveynin adı
        public int Yas { get; set; }  // Ebeveynin yaşı
        public List<Cocuk> Cocuklar { get; set; }  // Ebeveynin çocukları

        // Ebeveyn sınıfı yapıcı metot
        public Ebeveyn(string ad, int yas)
        {
            Ad = ad;
            Yas = yas;
            Cocuklar = new List<Cocuk>();  // Çocuklar listesi başlatılır
        }

        // Ebeveynin çocuklarına çocuk ekleme metodu
        public void CocukEkle(Cocuk cocuk)
        {
            Cocuklar.Add(cocuk);
            cocuk.EbeveynAta(this);  // Çocuğun ebeveynini bu ebeveyn olarak atar
        }
    }




}
 



