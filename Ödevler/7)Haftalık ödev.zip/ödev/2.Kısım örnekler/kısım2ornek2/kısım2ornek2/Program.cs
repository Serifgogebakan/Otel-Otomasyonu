﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım2ornek2{

    // Hasta sınıfı
    class Hasta{
        public string Ad { get; set; }  // Hastanın adı
        public string TCNo { get; set; }  // Hastanın TC kimlik numarası
        public Doktor Doktor { get; set; }  // Hastanın bağlı olduğu doktor

        // Hasta sınıfı yapıcı metot
        public Hasta(string ad, string tcNo){
            Ad = ad;
            TCNo = tcNo;
        }
        // Hasta için doktor atama metodu
        public void DoktorAta(Doktor doktor){
            Doktor = doktor;
        }


        // Hasta bilgilerini yazdıran metod
        public void EkranaYazdir(){
            Console.WriteLine($"Hasta Adı: {Ad}, TC No: {TCNo}, Doktor: {Doktor.Ad}");
        }


    }

    // Doktor sınıfı
    class Doktor{
        public string Ad { get; set; }  // Doktorun adı
        public string Brans { get; set; }  // Doktorun branşı
        public List<Hasta> Hastalar { get; set; }  // Doktorun hastalarının listesi

        // Doktor sınıfı yapıcı metot
        public Doktor(string ad, string brans){
            Ad = ad;
            Brans = brans;
            Hastalar = new List<Hasta>();  // Hastalar listesi başlatılır
        }

        // Doktora hasta ekleme metodu
        public void HastaEkle(Hasta hasta){
            Hastalar.Add(hasta);
            hasta.DoktorAta(this);  // Hastanın doktoru olarak bu doktor atanır
        }


        // Doktor bilgilerini yazdırma metodu
        public void EkranaYazdir(){
            Console.WriteLine($"Doktor Adı: {Ad}, Branş: {Brans}");
        }


    }

    // Program sınıfı (Main metodu içerir)
    class Program{
        static void Main(string[] args){
            // Doktor nesnesi oluşturuluyor
            Doktor doktor = new Doktor("ORD.PROF. Abuzer Kömürcü", "Biyokimya");

            // Hasta nesneleri oluşturuluyor
            Hasta hasta1 = new Hasta("Erdal Kömürcü", "12345678910");

            // Hastalar doktora ekleniyor
            doktor.HastaEkle(hasta1);

            // Doktor ve hastaların bilgileri ekrana yazdırır
            doktor.EkranaYazdir();
            Console.WriteLine("\nHastalar:");
            foreach (var hasta in doktor.Hastalar){
                hasta.EkranaYazdir();
            }
            Console.ReadLine();
        }
    }
}
