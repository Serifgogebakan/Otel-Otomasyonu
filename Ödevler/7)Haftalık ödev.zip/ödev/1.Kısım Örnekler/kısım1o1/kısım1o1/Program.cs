﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım1o1{
    // Kitap sınıfı
    class Kitap{
        public string Ad { get; set; }
        public string ISBN { get; set; }

        public Kitap(string ad, string isbn){
            Ad = ad;
            ISBN = isbn;
        }
    }

    // Yazar sınıfı
    class Yazar {
        public string Ad { get; set; }
        public List<Kitap> Kitaplar { get; set; } // Yazarın yazdığı kitaplar

        public Yazar(string ad){
            Ad = ad;
            Kitaplar = new List<Kitap>();
        }

        // Yazara kitap ekleme
        public void KitapEkle(Kitap kitap){

            Kitaplar.Add(kitap);
        }
    }
}
