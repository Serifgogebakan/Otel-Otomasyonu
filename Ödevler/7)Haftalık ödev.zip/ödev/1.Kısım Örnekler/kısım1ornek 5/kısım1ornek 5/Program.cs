﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım1ornek_5{

    // Ürün sınıfı
    class Urun{
        public string Ad { get; set; }  // Ürün adı
        public decimal Fiyat { get; set; }  // Ürün fiyatı

        // Ürün sınıfı yapıcı metot
        public Urun(string ad, decimal fiyat){
            Ad = ad;
            Fiyat = fiyat;
        }

        // Sipariş ver metodu
        public Siparis SiparisVer(){
            // Sipariş oluşturuluyor
            Siparis siparis = new Siparis(DateTime.Now, "Hazırlanıyor");
            Console.WriteLine($"Sipariş Verildi: {Ad} - Fiyat: {Fiyat:C}");
            return siparis;
        }
    }

    // Sipariş sınıfı
    class Siparis{
        public DateTime SiparisTarihi { get; set; }  // Siparişin tarihi
        public string Durum { get; set; }  // Siparişin durumu

        // Sipariş sınıfı yapıcı metot
        public Siparis(DateTime siparisTarihi, string durum)
        {
            SiparisTarihi = siparisTarihi;
            Durum = durum;
        }

    }
    class Program{
            static void Main(string[] args){

                // Ürün nesneleri oluşturur
                Urun urun1 = new Urun("Laptop", 30000);


                // Ürünlerin sipariş verilmesi
                Siparis siparis1 = urun1.SiparisVer();

                Console.ReadLine();

            }
        }

    
}
