﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım1ornek4{
    // Ürün sınıfı
    class Urun{
        public string Ad { get; set; }  // Ürün adı
        public decimal Fiyat { get; set; }  // Ürün fiyatı

        // Ürün sınıfı yapıcı metot
        public Urun(string ad, decimal fiyat){
            Ad = ad;
            Fiyat = fiyat;
        }

        // Ürüne ait bilgilerin yazdırılması
        public void UrunBilgisi(){
            Console.WriteLine($"Ürün Adı: {Ad}, Fiyat: {Fiyat:C}");
        }
    }

    // Sipariş sınıfı
    class Siparis{
        public DateTime SiparisTarihi { get; set; } // Siparişin tarihi
        public decimal ToplamFiyat { get; set; } // Siparişin toplam fiyatı

        // Sipariş sınıfı yapıcı metot
        public Siparis(){
            SiparisTarihi = DateTime.Now; // Sipariş oluşturulma tarihi
            ToplamFiyat = 0; // Başlangıçta toplam fiyat 0
        }

        // Siparişe ürün ekleme metodu
        public void UrunEkle(Urun urun){
            ToplamFiyat += urun.Fiyat; // Ürün eklendikçe toplam fiyat hesaplanır
        }

        // Siparişin bilgilerini yazdırma
        public void SiparisBilgisi(){
            Console.WriteLine($"Sipariş Tarihi: {SiparisTarihi.ToString("dd.MM.yyyy HH:mm:ss")}");
            Console.WriteLine($"Toplam Fiyat: {ToplamFiyat:C}");
        }
    }


    class Program{
        static void Main(string[] args){

            // Ürün nesneleri oluşturur

            Urun urun1 = new Urun("Telefon",15000); 

            // Sipariş nesnesi oluşturur
            Siparis siparis = new Siparis();

            // Ürün siparişe eklenir
            siparis.UrunEkle(urun1);


            // Sipariş bilgileri ekrana yazdırılır
            siparis.SiparisBilgisi();
            Console.ReadLine();
        }
    }

}
