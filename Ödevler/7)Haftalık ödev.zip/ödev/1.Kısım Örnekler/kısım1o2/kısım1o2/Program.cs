﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kısım1o2{
    class Departman{
        public string Ad { get; set; }
        public string Konum { get; set; }

        // Departman sınıfı yapıcı metot
        public Departman(string ad, string konum){

            Ad = ad;
            Konum = konum;
        }
    }

    // Çalışan sınıfı
    class Calisan{
        public string Ad { get; set; }
        public string Pozisyon { get; set; }
        public Departman Departman { get; private set; } // Çalışanın ait olduğu departman

    
        // Çalışan sınıfı yapıcı metot
        public Calisan(string ad, string pozisyon){
            Ad = ad;
            Pozisyon = pozisyon;
        }
        // Çalışanı bir departmana ekleme metodu
        public void DepartmanEkle(Departman departman){
            Departman = departman;
        }
    }

    class Program{
        static void Main(string[] args){

            // Bir Departman nesnesi oluşturulur.
            Departman departman = new Departman("YMT LAB", "2.Kat");

            // Bir Çalışan nesnesi oluşturulur.
            Calisan calisan = new Calisan("XXX xxx", "Yazılım Öğrencisi");

            // Çalışan, departmana atanır.
            calisan.DepartmanEkle(departman);

            // Bilgiler ekrana yazdırılır.
            Console.WriteLine($"Çalışan Adı: {calisan.Ad}");
            Console.WriteLine($"Pozisyon: {calisan.Pozisyon}");
            Console.WriteLine($"Departman: {calisan.Departman.Ad}");
            Console.WriteLine($"Konum: {calisan.Departman.Konum}");

            Console.ReadLine();
        }
    }

}