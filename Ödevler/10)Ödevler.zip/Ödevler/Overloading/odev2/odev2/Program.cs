﻿using System;

namespace Odev2
{
    class Program
    {
        // İlk sürüm: Karenin alanını hesaplama (Bir kenar uzunluğu verilerek)
        static int AlanHesapla(int kenar)
        {
            return kenar * kenar;  // Karenin alanı: kenar^2
        }

        // İkinci sürüm: Dikdörtgenin alanını hesaplama (İki kenar uzunluğu verilerek)
        static double AlanHesapla(double uzunluk, double genislik)
        {
            return uzunluk * genislik;  // Dikdörtgenin alanı: uzunluk * genişlik
        }

        // Üçüncü sürüm: Dairenin alanını hesaplama (Yarıçap verilerek)
        static double AlanHesapla(double yariCap)
        {
            return Math.PI * yariCap * yariCap;  // Dairenin alanı: π * yarıçap^2
        }

        static void Main()
        {
            // İlk sürüm örneği: Karenin alanı
            double kareAlan = AlanHesapla(5);
            Console.WriteLine("Karenin alanı: " + kareAlan);

            // İkinci sürüm örneği: Dikdörtgenin alanı
            double dikdortgenAlan = AlanHesapla(5, 10);
            Console.WriteLine("Dikdörtgenin alanı: " + dikdortgenAlan);

            // Üçüncü sürüm örneği: Dairenin alanı
            double daireAlan = AlanHesapla(7);
            Console.WriteLine("Dairenin alanı: " + daireAlan);

            Console.ReadLine();
        }
    }
}
