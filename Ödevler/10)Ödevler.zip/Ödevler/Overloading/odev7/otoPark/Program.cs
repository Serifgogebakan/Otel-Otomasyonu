﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtoparkSistemi
{
    class Otopark
    {
        // Otopark, her biri park yeri içeren katlardan oluşuyor
        private string[,] parkYerleri;

        // Constructor: Otopark sınıfı, katlar ve park yerlerini başlatıyoruz
        public Otopark(int katSayisi, int parkYeriSayisi)
        {
            parkYerleri = new string[katSayisi, parkYeriSayisi];

            // Başlangıçta tüm park yerleri "Empty"
            for (int i = 0; i < katSayisi; i++)
            {
                for (int j = 0; j < parkYeriSayisi; j++)
                {
                    parkYerleri[i, j] = "Empty";  // Boş park yeri
                }
            }
        }

        // Otoparkta kat ve park yeri indeksleyicisi
        public string this[int kat, int parkYeri]
        {
            get
            {
                // Kat numarası geçerli mi? Katlar 0'dan başlayacak, örneğin 0. kat, 1. kat vs.
                if (kat < 0 || kat >= parkYerleri.GetLength(0) || parkYeri < 0 || parkYeri >= parkYerleri.GetLength(1))
                {
                    return "Geçersiz kat veya park yeri!";
                }

                return parkYerleri[kat, parkYeri];
            }

            set
            {
                // Kat numarası geçerli mi?
                if (kat < 0 || kat >= parkYerleri.GetLength(0) || parkYeri < 0 || parkYeri >= parkYerleri.GetLength(1))
                {
                    Console.WriteLine("Geçersiz kat veya park yeri!");
                    return;
                }

                // Park yeri doluysa, yeni araç yerleştirilemez
                if (parkYerleri[kat, parkYeri] != "Empty")
                {
                    Console.WriteLine("Bu park yeri zaten dolu! Araç plakası: " + parkYerleri[kat, parkYeri]);
                }
                else
                {
                    parkYerleri[kat, parkYeri] = value;  // Araç plakası koyuluyor
                    Console.WriteLine($"{kat + 1} numaralı katın {parkYeri + 1} numaralı park yerine araç eklendi: {value}");
                }
            }
        }

        // Otoparkın durumunu ekrana yazdırma
        public void OtoparkDurumunuGoster()
        {
            Console.WriteLine("\nOtopark Durumu:");
            for (int i = 0; i < parkYerleri.GetLength(0); i++)
            {
                Console.Write($"Kat {i + 1}: ");
                for (int j = 0; j < parkYerleri.GetLength(1); j++)
                {
                    Console.Write($"[{parkYerleri[i, j]}] ");
                }
                Console.WriteLine();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // 3 kat, her kat için 5 park yeri olan bir otopark oluşturuyoruz
            Otopark otopark = new Otopark(3, 5);

            // Otoparkın başlangıç durumunu göster
            otopark.OtoparkDurumunuGoster();

            // Kullanıcıdan park yeri seçme ve araç yerleştirme
            Console.WriteLine("\nBir park yerine araç eklemek için kat numarasını ve park yeri numarasını girin.");
            Console.Write("Kat numarasını girin (1-3): ");
            int kat = int.Parse(Console.ReadLine()) - 1;  // Kullanıcı 1 tabanlı giriş yapıyor, biz 0 tabanlı diziyi kullanıyoruz

            Console.Write("Park yeri numarasını girin (1-5): ");
            int parkYeri = int.Parse(Console.ReadLine()) - 1;  // Kullanıcı 1 tabanlı giriş yapıyor

            Console.Write("Araç plakasını girin: ");
            string plaka = Console.ReadLine();

            // Araç plakasını ilgili park yerine yerleştiriyoruz
            otopark[kat, parkYeri] = plaka;

            // Otoparkın güncel durumunu göster
            otopark.OtoparkDurumunuGoster();

            // Geçersiz park yeri ve kat girildiğinde hata mesajı
            Console.WriteLine("\nGeçersiz park yeri örneği:");
            Console.WriteLine(otopark[3, 1]);  // Geçersiz kat (katlar 0-2 arası)
            Console.WriteLine(otopark[0, 6]);  // Geçersiz park yeri (park yerleri 0-4 arası)
        }
    }
}
