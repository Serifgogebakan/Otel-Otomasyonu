﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPSKonumMesafesi
{
    // GPS koordinatlarını temsil eden struct
    public struct GPSKonumu
    {
        public double Latitude { get; set; }  // Enlem
        public double Longitude { get; set; } // Boylam

        // Constructor: GPS koordinatları oluşturulurken enlem ve boylam alınır
        public GPSKonumu(double latitude, double longitude)
        {
            Latitude = latitude;
            Longitude = longitude;
        }

        // Haversine formülünü kullanarak iki GPS konumu arasındaki mesafeyi hesaplayan metot
        public static double MesafeHesapla(GPSKonumu konum1, GPSKonumu konum2)
        {
            // Haversine formülü için gerekli hesaplamalar
            double R = 6371; // Dünya'nın yarıçapı (km cinsinden)
            double lat1 = DegreseToRadians(konum1.Latitude);
            double lat2 = DegreseToRadians(konum2.Latitude);
            double deltaLat = DegreseToRadians(konum2.Latitude - konum1.Latitude);
            double deltaLong = DegreseToRadians(konum2.Longitude - konum1.Longitude);

            // Haversine formülü
            double a = Math.Sin(deltaLat / 2) * Math.Sin(deltaLat / 2) +
                       Math.Cos(lat1) * Math.Cos(lat2) *
                       Math.Sin(deltaLong / 2) * Math.Sin(deltaLong / 2);
            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

            // Mesafe (km)
            return R * c;
        }

        // Dereceyi radyana çeviren yardımcı metot
        private static double DegreseToRadians(double derece)
        {
            return derece * (Math.PI / 180);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Kullanıcıdan iki GPS konumu alıyoruz
            Console.Write("Birinci GPS konumunu girin (Enlem, Boylam): ");
            string[] konum1Input = Console.ReadLine().Split(',');
            double lat1 = double.Parse(konum1Input[0].Trim());
            double long1 = double.Parse(konum1Input[1].Trim());

            Console.Write("İkinci GPS konumunu girin (Enlem, Boylam): ");
            string[] konum2Input = Console.ReadLine().Split(',');
            double lat2 = double.Parse(konum2Input[0].Trim());
            double long2 = double.Parse(konum2Input[1].Trim());

            // GPS konumu nesnelerini oluşturuyoruz
            GPSKonumu konum1 = new GPSKonumu(lat1, long1);
            GPSKonumu konum2 = new GPSKonumu(lat2, long2);

            // Mesafeyi hesaplıyoruz
            double mesafe = GPSKonumu.MesafeHesapla(konum1, konum2);

            // Sonucu ekrana yazdırıyoruz
            Console.WriteLine($"\nİki GPS konumu arasındaki mesafe: {mesafe:F2} km");
        }
    }
}
