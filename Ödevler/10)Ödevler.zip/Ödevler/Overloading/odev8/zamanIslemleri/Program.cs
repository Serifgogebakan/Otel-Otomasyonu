﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZamanIslemleri
{
    // Zamanı temsil eden struct
    public struct Zaman
    {
        // Saat ve dakika özellikleri
        public int Hour { get; set; }
        public int Minute { get; set; }

        // Constructor: Zaman nesnesi oluşturulduğunda geçersiz değerler kontrol edilir
        public Zaman(int hour, int minute)
        {
            // Geçersiz saat veya dakika kontrolü
            if (hour < 0 || hour >= 24)  // Saat 0 ile 23 arasında olmalı
                Hour = 0;
            else
                Hour = hour;

            if (minute < 0 || minute >= 60)  // Dakika 0 ile 59 arasında olmalı
                Minute = 0;
            else
                Minute = minute;
        }

        // Zamanın toplam dakika cinsinden değerini döndüren metot
        public int ToplamDakika()
        {
            return (Hour * 60) + Minute;
        }

        // İki zaman nesnesi arasındaki farkı dakika cinsinden hesaplayan metot
        public static int Fark(Zaman zaman1, Zaman zaman2)
        {
            int toplamDakika1 = zaman1.ToplamDakika();
            int toplamDakika2 = zaman2.ToplamDakika();

            return Math.Abs(toplamDakika1 - toplamDakika2); // Mutlak fark
        }

        // Zamanın görsel temsilini döndüren metot (string)
        public override string ToString()
        {
            return $"{Hour:D2}:{Minute:D2}"; // Saat ve dakika sıfır dolu formatta gösterilir (Örn: 08:05)
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Kullanıcıdan saat ve dakika alıp Zaman nesneleri oluşturuyoruz
            Console.Write("Saat (0-23 arası bir değer girin): ");
            int saat = int.Parse(Console.ReadLine());

            Console.Write("Dakika (0-59 arası bir değer girin): ");
            int dakika = int.Parse(Console.ReadLine());

            // Zaman nesnesini oluşturuyoruz
            Zaman zaman1 = new Zaman(saat, dakika);
            Console.WriteLine($"Girilen Zaman: {zaman1}");

            // Kullanıcıdan başka bir zaman alalım
            Console.Write("\nİkinci zaman için saat girin: ");
            saat = int.Parse(Console.ReadLine());

            Console.Write("İkinci zaman için dakika girin: ");
            dakika = int.Parse(Console.ReadLine());

            // Zaman nesnesini oluşturuyoruz
            Zaman zaman2 = new Zaman(saat, dakika);
            Console.WriteLine($"İkinci Zaman: {zaman2}");

            // Zamanlar arasındaki farkı dakika olarak hesaplayalım
            int fark = Zaman.Fark(zaman1, zaman2);
            Console.WriteLine($"\nİki zaman arasındaki fark: {fark} dakika");
        }
    }
}
