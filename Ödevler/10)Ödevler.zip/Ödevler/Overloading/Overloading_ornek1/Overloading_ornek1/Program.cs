﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overloading_ornek1
{
    class Program
    {
        static void Main()
        {
            // 1. Kullanım: İki tam sayı toplama
            int a = 5, b = 10;
            Console.WriteLine("İki sayının toplamı: " + Topla(a, b));

            // 2. Kullanım: Üç tam sayı toplama
            int c = 15;
            Console.WriteLine("Üç sayının toplamı: " + Topla(a, b, c));

            // 3. Kullanım: Dizi (array) tam sayıları toplama
            int[] arr = { 1, 2, 3, 4, 5 };
            Console.WriteLine("Dizinin toplamı: " + Topla(arr));

        }


        // 1. İki tam sayıyı toplayan fonksiyon
        static int Topla(int a, int b)
        {
            return a + b;
        }

        // 2. Üç tam sayıyı toplayan fonksiyon
        static int Topla(int a, int b, int c)
        {
            return a + b + c;
        }

        // 3. Bir dizi (array) tam sayıyı toplayan fonksiyon
        static int Topla(int[] arr)
        {
            int toplam = 0;
            foreach (int sayi in arr)
            {
                toplam += sayi;
            }
            return toplam;
        }
    }
       
}
