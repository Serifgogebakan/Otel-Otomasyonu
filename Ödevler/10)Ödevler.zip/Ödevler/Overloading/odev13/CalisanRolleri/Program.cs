﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalisanRolleri
{
    // Çalışan rolleri için enum oluşturuyoruz
    public enum CalisanRolu
    {
        Manager,   // Yönetici
        Developer, // Yazılım Geliştirici
        Designer,  // Tasarımcı
        Tester     // Test Uzmanı
    }

    // Maaş hesaplama sınıfı
    public class MaaşHesaplama
    {
        // Çalışan rolüne göre maaşı hesaplayan metot
        public static decimal MaaşHesapla(CalisanRolu rol)
        {
            decimal maas = 0;

            switch (rol)
            {
                case CalisanRolu.Manager:
                    maas = 8000m;  // Yönetici maaşı
                    break;
                case CalisanRolu.Developer:
                    maas = 6000m;  // Yazılım geliştirici maaşı
                    break;
                case CalisanRolu.Designer:
                    maas = 5000m;  // Tasarımcı maaşı
                    break;
                case CalisanRolu.Tester:
                    maas = 4000m;  // Test uzmanı maaşı
                    break;
                default:
                    Console.WriteLine("Geçersiz çalışan rolü.");
                    break;
            }

            return maas;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Kullanıcıdan çalışan rolü alalım
            Console.WriteLine("Çalışan rolünü seçin: (Manager, Developer, Designer, Tester)");
            string input = Console.ReadLine();

            // Enum'a çeviriyoruz
            CalisanRolu rol;
            if (Enum.TryParse(input, true, out rol))
            {
                // Maaş hesapla ve sonucu ekrana yazdır
                decimal maas = MaaşHesaplama.MaaşHesapla(rol);
                Console.WriteLine($"{rol} maaşı: {maas} TL");
            }
            else
            {
                Console.WriteLine("Geçersiz bir çalışan rolü girdiniz.");
            }
        }
    }
}
