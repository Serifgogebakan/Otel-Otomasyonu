﻿using System;
using System.Runtime.CompilerServices;  // TupleElementNamesAttribute için gerekli

namespace Odev3
{
    class Program
    {
        // İlk sürüm: İki tarih arasındaki farkı gün cinsinden hesaplama
        static int ZamanFarki(DateTime tarih1, DateTime tarih2)
        {
            TimeSpan fark = tarih2 - tarih1;  // İki tarih arasındaki fark
            return (int)fark.TotalDays;  // Gün cinsinden fark
        }

        // İkinci sürüm: İki tarih arasındaki farkı saat cinsinden hesaplama
        static double ZamanFarkiSaat(DateTime tarih1, DateTime tarih2)
        {
            TimeSpan fark = tarih2 - tarih1;  // İki tarih arasındaki fark
            return fark.TotalHours;  // Saat cinsinden fark
        }

        // Üçüncü sürüm: İki tarih arasındaki farkı yıl, ay ve gün cinsinden hesaplama
        static (int yil, int ay, int gun) ZamanFarkiYilAyGun(DateTime tarih1, DateTime tarih2)
        {
            int yil = tarih2.Year - tarih1.Year;
            int ay = tarih2.Month - tarih1.Month;
            int gun = tarih2.Day - tarih1.Day;

            // Eğer gün farkı negatifse, aydan bir çıkar ve günü düzelt
            if (gun < 0)
            {
                ay--;
                gun += DateTime.DaysInMonth(tarih2.Year, tarih2.Month); // Ayın sonundaki gün sayısını ekleriz
            }

            // Eğer ay farkı negatifse, yıldan bir çıkar ve ayı düzelt
            if (ay < 0)
            {
                yil--;
                ay += 12; // Yıl farkı kadar ayı ekleriz
            }

            return (yil, ay, gun);  // Yıl, ay, gün cinsinden fark
        }

        static void Main()
        {
            // Örnek tarihleri oluşturuyoruz
            DateTime tarih1 = new DateTime(2020, 5, 15);
            DateTime tarih2 = new DateTime(2023, 12, 25);

            // İlk sürüm: Gün cinsinden fark
            int gunFarki = ZamanFarki(tarih1, tarih2);
            Console.WriteLine("İki tarih arasındaki fark (gün cinsinden): " + gunFarki + " gün");
            Console.ReadLine();  // Kullanıcıdan bir giriş bekleyerek ekranı tut

            // İkinci sürüm: Saat cinsinden fark
            double saatFarki = ZamanFarkiSaat(tarih1, tarih2);
            Console.WriteLine("İki tarih arasındaki fark (saat cinsinden): " + saatFarki + " saat");
            Console.ReadLine();  // Kullanıcıdan bir giriş bekleyerek ekranı tut

            // Üçüncü sürüm: Yıl, ay ve gün cinsinden fark
            var fark = ZamanFarkiYilAyGun(tarih1, tarih2);
            Console.WriteLine($"İki tarih arasındaki fark: {fark.yil} yıl, {fark.ay} ay, {fark.gun} gün");
            Console.ReadLine();  // Kullanıcıdan bir giriş bekleyerek ekranı tut
        }
    }
}

