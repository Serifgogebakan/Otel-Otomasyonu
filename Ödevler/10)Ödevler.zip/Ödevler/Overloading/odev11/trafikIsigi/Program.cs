﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace trafikIsigi
{ // Trafik ışığı durumlarını temsil eden enum
    public enum TrafikIsigiDurumu
    {
        Red,    // Kırmızı ışık
        Yellow, // Sarı ışık
        Green   // Yeşil ışık
    }

    // Trafik ışığı sınıfı
    public class TrafikIsigi
    {
        // Enum'a göre yapılması gereken işlemi döndüren metot
        public static string NeYapilmali(TrafikIsigiDurumu durum)
        {
            switch (durum)
            {
                case TrafikIsigiDurumu.Red:
                    return "Dur, geçemezsin!";
                case TrafikIsigiDurumu.Yellow:
                    return "Hazır ol, bekle!";
                case TrafikIsigiDurumu.Green:
                    return "Geçebilirsin!";
                default:
                    return "Geçersiz ışık durumu!";
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Kullanıcıdan trafik ışığı durumu alalım
            Console.WriteLine("Trafik ışığı durumunu seçin: (Red, Yellow, Green)");
            string input = Console.ReadLine();

            // Enum'a çeviriyoruz
            TrafikIsigiDurumu durum;
            if (Enum.TryParse(input, true, out durum))
            {
                // Duruma göre yapılacak işlemi yazdırıyoruz
                string mesaj = TrafikIsigi.NeYapilmali(durum);
                Console.WriteLine(mesaj);
            }
            else
            {
                Console.WriteLine("Geçersiz bir ışık durumu girdiniz.");
            }
        }
    }
}
