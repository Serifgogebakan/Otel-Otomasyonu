﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace havaDurumu
{
    // Hava durumu tiplerini temsil eden enum
    public enum HavaDurumu
    {
        Gunesli,  // Güneşli
        Yogmurlu,  // Yağmurlu
        Bulutlu, // Bulutlu
        Firtinali  // Fırtınalı
    }

    // Hava durumu tavsiye sınıfı
    public class HavaDurumuTavsiyesi
    {
        // Enum'a göre tavsiye veren metot
        public static string TavsiyeVer(HavaDurumu durumu)
        {
            switch (durumu)
            {
                case HavaDurumu.Gunesli:
                    return "Bugün güneşli! Dışarı çıkıp keyif yapabilirsiniz.";
                case HavaDurumu.Yogmurlu:
                    return "Yağmurlu bir gün! Şemsiye almayı unutmayın.";
                case HavaDurumu.Bulutlu:
                    return "Bulutlu bir hava var. Dışarıda çok soğuk olmayabilir, ama yine de hazırlıklı olun.";
                case HavaDurumu.Firtinali:
                    return "Fırtına var! Evde kalın, dışarı çıkmamaya özen gösterin.";
                default:
                    return "Geçersiz hava durumu!";
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Kullanıcıdan hava durumu bilgisi alalım
            Console.WriteLine("Hava durumu seçin: (Gunesli, Yogmurlu, Bulutlu, Firtinali)");
            string input = Console.ReadLine();

            // Enum'a çeviriyoruz
            HavaDurumu durum;
            if (Enum.TryParse(input, true, out durum))
            {
                // Duruma göre tavsiyeyi yazdırıyoruz
                string tavsiye = HavaDurumuTavsiyesi.TavsiyeVer(durum);
                Console.WriteLine(tavsiye);
            }
            else
            {
                Console.WriteLine("Geçersiz bir hava durumu girdiniz.");
            }
        }
    }
}
