﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarmaşıkSayilar
{
    // Karmaşık sayıyı temsil eden struct
    public struct KarmaşikSayi
    {
        // Gerçek (real) ve sanal (imaginary) kısımlar
        public double Real { get; set; }
        public double Imaginary { get; set; }

        // Constructor: Karmaşık sayıyı oluştururken gerçek ve sanal kısmı alır
        public KarmaşikSayi(double real, double imaginary)
        {
            Real = real;
            Imaginary = imaginary;
        }

        // Toplama işlemi: İki karmaşık sayıyı toplar
        public static KarmaşikSayi operator +(KarmaşikSayi sayi1, KarmaşikSayi sayi2)
        {
            return new KarmaşikSayi(sayi1.Real + sayi2.Real, sayi1.Imaginary + sayi2.Imaginary);
        }

        // Çıkarma işlemi: İki karmaşık sayıyı çıkarır
        public static KarmaşikSayi operator -(KarmaşikSayi sayi1, KarmaşikSayi sayi2)
        {
            return new KarmaşikSayi(sayi1.Real - sayi2.Real, sayi1.Imaginary - sayi2.Imaginary);
        }

        // Karmaşık sayının string formatında yazılmasını sağlayan metot
        public override string ToString()
        {
            if (Imaginary >= 0)
                return $"{Real} + {Imaginary}i";
            else
                return $"{Real} - {Math.Abs(Imaginary)}i";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Kullanıcıdan karmaşık sayılar alalım
            Console.Write("Birinci karmaşık sayıyı girin (gerçek kısım, sanal kısım): ");
            string[] sayi1 = Console.ReadLine().Split(',');
            double real1 = double.Parse(sayi1[0].Trim());
            double imaginary1 = double.Parse(sayi1[1].Trim());

            Console.Write("İkinci karmaşık sayıyı girin (gerçek kısım, sanal kısım): ");
            string[] sayi2 = Console.ReadLine().Split(',');
            double real2 = double.Parse(sayi2[0].Trim());
            double imaginary2 = double.Parse(sayi2[1].Trim());

            // Karmaşık sayılar nesnelerini oluşturuyoruz
            KarmaşikSayi sayi1Obj = new KarmaşikSayi(real1, imaginary1);
            KarmaşikSayi sayi2Obj = new KarmaşikSayi(real2, imaginary2);

            // Toplama işlemi
            KarmaşikSayi toplam = sayi1Obj + sayi2Obj;
            Console.WriteLine($"\nToplama Sonucu: {toplam}");

            // Çıkarma işlemi
            KarmaşikSayi fark = sayi1Obj - sayi2Obj;
            Console.WriteLine($"Çıkarma Sonucu: {fark}");
        }
    }
}
