﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev6
{
    class SatrançTahtası
    {
        // Satranç tahtasında 8x8'lik bir dizi oluşturuluyor
        private string[,] tahtadakiKareler = new string[8, 8];

        // Constructor: Tahtayı başlatıyoruz (başlangıçta boş)
        public SatrançTahtası()
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    tahtadakiKareler[i, j] = "";  // Başlangıçta her kare boş
                }
            }
        }

        // Satranç tahtasındaki kareye taş koyma veya taşın ne olduğunu öğrenme
        public string this[string kare]
        {
            get
            {
                // Kareyi geçerli bir biçimde kontrol ediyoruz (örneğin: A1, B2, E5)
                if (kare.Length != 2)
                {
                    return "Geçersiz kare! Kareyi doğru formatta girin (örneğin: A1, E5).";
                }

                char sutun = kare[0];
                int satir = int.Parse(kare[1].ToString());

                // Satır ve sütun geçerli mi kontrol ediliyor (A-H, 1-8 arası)
                if (sutun < 'A' || sutun > 'H' || satir < 1 || satir > 8)
                {
                    return "Geçersiz kare! Satır 1-8, sütun A-H arasında olmalıdır.";
                }

                // Satranç tahtasında belirli bir kareyi almak için hesaplama
                int x = 8 - satir; // Satırları ters çevirmek (1-8 arası, diziler 0'dan başlar)
                int y = sutun - 'A'; // Sütunları 0-7 arası bir değere dönüştürmek

                return string.IsNullOrEmpty(tahtadakiKareler[x, y]) ? "Boş" : tahtadakiKareler[x, y];
            }
            set
            {
                // Kareyi geçerli bir biçimde kontrol ediyoruz
                if (kare.Length != 2)
                {
                    Console.WriteLine("Geçersiz kare! Kareyi doğru formatta girin (örneğin: A1, E5).");
                    return;
                }

                char sutun = kare[0];
                int satir = int.Parse(kare[1].ToString());

                if (sutun < 'A' || sutun > 'H' || satir < 1 || satir > 8)
                {
                    Console.WriteLine("Geçersiz kare! Satır 1-8, sütun A-H arasında olmalıdır.");
                    return;
                }

                // Satranç tahtasında belirli bir kareyi güncellemek için hesaplama
                int x = 8 - satir; // Satırları ters çevirmek (1-8 arası, diziler 0'dan başlar)
                int y = sutun - 'A'; // Sütunları 0-7 arası bir değere dönüştürmek

                tahtadakiKareler[x, y] = value;
                Console.WriteLine($"{kare} karesine '{value}' taşını koydunuz.");
            }
        }

        // Tahtayı ekrana yazdırma (isteğe bağlı)
        public void TahtayıGoster()
        {
            Console.WriteLine("\nSatranç Tahtası:");
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Console.Write(tahtadakiKareler[i, j] == "" ? "[ ]" : "[" + tahtadakiKareler[i, j] + "]");
                }
                Console.WriteLine();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Satranç tahtasını oluşturuyoruz
            SatrançTahtası tahtam = new SatrançTahtası();

            // Başlangıçta boş bir tahta gösteriyoruz
            tahtam.TahtayıGoster();

            // Kullanıcı bir kareye taş koysun
            Console.WriteLine("\nBir kareye taş koymak için kareyi (örneğin: A1, E5) girin:");
            string kare = Console.ReadLine();
            Console.WriteLine("Hangi taşı koymak istersiniz? (örneğin: At, Kale, Piyon):");
            string tas = Console.ReadLine();

            // Taşı ilgili kareye koyuyoruz
            tahtam[kare] = tas;

            // Tahtayı tekrar gösteriyoruz
            tahtam.TahtayıGoster();

            // Geçersiz bir kareye taş koyma örneği
            Console.WriteLine("\nGeçersiz bir kare örneği (Z9 gibi):");
            tahtam["Z9"] = "At";  // Geçersiz kare
            Console.WriteLine(tahtam["Z9"]);  // Hata mesajı

            // Geçersiz bir taş ismi girme örneği
            Console.WriteLine("\nGeçersiz bir taş ismi girin:");
            tahtam["D4"] = "Fil";  // Geçersiz taş ismi
            Console.WriteLine(tahtam["D4"]);
        }
    }
}
