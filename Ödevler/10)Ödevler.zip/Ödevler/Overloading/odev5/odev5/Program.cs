﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OgrenciNotSistemi
{
    class Ogrenci
    {
        // Ders adlarını ve ders notlarını saklamak için diziler
        private string[] dersler;
        private double[] notlar;

        // Constructor ile dersleri ve notları başlatıyoruz
        public Ogrenci(string[] dersler)
        {
            this.dersler = dersler;
            this.notlar = new double[dersler.Length];  // Notlar dizisini derslerin sayısına göre oluşturuyoruz
        }

        // İndeksleyici tanımlanıyor. Kullanıcı ders adına göre notu alabilir veya değiştirebilir.
        public double this[string dersAdi]
        {
            get
            {
                // Ders adı geçerli mi kontrol ediliyor
                for (int i = 0; i < dersler.Length; i++)
                {
                    if (dersler[i].ToLower() == dersAdi.ToLower())
                    {
                        return notlar[i];  // Ders bulunduğunda notu döndür
                    }
                }
                // Ders bulunamadıysa hata mesajı döndürülüyor
                Console.WriteLine("Hata: Böyle bir ders bulunmamaktadır.");
                return -1;  // Geçersiz not
            }
            set
            {
                // Ders adı geçerli mi kontrol ediliyor
                for (int i = 0; i < dersler.Length; i++)
                {
                    if (dersler[i].ToLower() == dersAdi.ToLower())
                    {
                        notlar[i] = value;  // Geçerli dersin notunu güncelle
                        Console.WriteLine($"{dersAdi} dersi için yeni not: {value}");
                        return;
                    }
                }
                // Ders bulunamadıysa hata mesajı döndürülüyor
                Console.WriteLine("Hata: Böyle bir ders bulunmamaktadır.");
            }
        }

        // Tüm derslerin notlarını ekrana yazdırma
        public void NotlariGoster()
        {
            Console.WriteLine("\nÖğrencinin Ders Notları:");
            for (int i = 0; i < dersler.Length; i++)
            {
                Console.WriteLine($"{dersler[i]}: {notlar[i]}");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Öğrencinin aldığı derslerin isimlerini belirliyoruz
            string[] dersler = { "Matematik", "Fizik", "Kimya", "Türkçe", "Edebiyat" };

            // Öğrenciyi oluşturuyoruz
            Ogrenci ogrenci = new Ogrenci(dersler);

            // Başlangıçta derslerin notlarını güncelliyoruz
            ogrenci["Matematik"] = 85.5;
            ogrenci["Fizik"] = 92.0;
            ogrenci["Kimya"] = 78.5;
            ogrenci["Türkçe"] = 88.0;
            ogrenci["Edebiyat"] = 91.5;

            // Öğrencinin ders notlarını gösteriyoruz
            ogrenci.NotlariGoster();

            // Kullanıcıya bir ders adı soralım ve notunu değiştirelim
            Console.WriteLine("\nBir ders adı girin ve notunu güncelleyin: ");
            string dersAdi = Console.ReadLine();
            Console.WriteLine("Yeni notu girin: ");
            double yeniNot = Convert.ToDouble(Console.ReadLine());

            // Ders notunu güncelliyoruz
            ogrenci[dersAdi] = yeniNot;

            // Güncellenmiş notları tekrar gösteriyoruz
            ogrenci.NotlariGoster();

            // Geçersiz ders adı örneği
            Console.WriteLine("\nGeçersiz ders adı örneği:");
            ogrenci["Biyoloji"] = 95.0;  // Geçersiz ders adı
            Console.WriteLine(ogrenci["Biyoloji"]);  // Geçersiz ders adı mesajı
        }
    }
}