﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KitapYonetimSistemi
{
    class KitapKoleksiyonu
    {
        // Kitap koleksiyonu, yani dizi
        private string[] kitaplar;

        // Constructor ile kitap koleksiyonunu başlatıyoruz
        public KitapKoleksiyonu(int koleksiyonBoyutu)
        {
            kitaplar = new string[koleksiyonBoyutu];
        }

        // İndeksleyici tanımlanıyor. Kullanıcı belirli bir indekste kitap adını alabilir veya değiştirebilir.
        public string this[int index]
        {
            get
            {
                // Geçersiz indeks kontrolü
                if (index < 0 || index >= kitaplar.Length)
                {
                    return "Geçersiz indeks!";
                }
                return kitaplar[index];
            }
            set
            {
                // Geçersiz indeks kontrolü
                if (index < 0 || index >= kitaplar.Length)
                {
                    Console.WriteLine("Geçersiz indeks! Kitap adı güncellenemedi.");
                }
                else
                {
                    kitaplar[index] = value;
                    Console.WriteLine($"Kitap {index + 1}. sıraya '{value}' olarak güncellendi.");
                }
            }
        }

        // Kitapları ekrana yazdırma
        public void KitaplariGoster()
        {
            for (int i = 0; i < kitaplar.Length; i++)
            {
                Console.WriteLine($"{i + 1}. Kitap: {kitaplar[i]}");
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Kitap koleksiyonu oluşturuluyor
            KitapKoleksiyonu koleksiyon = new KitapKoleksiyonu(5);  // 5 kitaplık bir koleksiyon

            // Kitapları ekliyoruz (ilk başta boş)
            koleksiyon[0] = "Yüzüklerin Efendisi";
            koleksiyon[1] = "Harry Potter";
            koleksiyon[2] = "Sefiller";
            koleksiyon[3] = "Kırmızı Pazartesi";
            koleksiyon[4] = "1984";

            // Kitapları gösteriyoruz
            Console.WriteLine("Kitap Koleksiyonu:");
            koleksiyon.KitaplariGoster();
            Console.WriteLine();

            // Kullanıcıya kitap adını değiştirmesi için fırsat veriyoruz
            Console.WriteLine("Kitap adını değiştirmek için indeks numarası girin (0-4 arası): ");
            int indeks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Yeni kitap adını girin: ");
            string yeniKitapAdi = Console.ReadLine();

            // Kitap adını değiştiriyoruz
            koleksiyon[indeks] = yeniKitapAdi;

            // Kitapları tekrar gösteriyoruz
            Console.WriteLine("\nGüncellenmiş Kitap Koleksiyonu:");
            koleksiyon.KitaplariGoster();

            // Geçersiz indeks kullanımı
            Console.WriteLine("\nGeçersiz indeks örneği:");
            koleksiyon[10] = "Yeni Kitap";  // Geçersiz indeks
            Console.WriteLine(koleksiyon[10]);  // Geçersiz indeks mesajı
        }
    }
}
