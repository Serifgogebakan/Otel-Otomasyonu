﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace xox_oyun
{
    public partial class Form1 : Form
    {
        private string oyuncu1, oyuncu2;
        private int boyut = 3;               // Varsayılan boyut 3x3 yapar
        private Button[,] oyunButonlari;    // Oyun alanındaki butonlar
        private bool oyuncu1Sirada = true; // Oyuncu sırasını tutar, true = 1.Oyuncu   false = 2.Oyuncu 
        private int oyuncu1Skor = 0;
        private int oyuncu2Skor = 0;

        public Form1()
        {
            InitializeComponent();

            // Boyut seçeneklerini ComboBox'a eklediğimiz kısım
            comboBoxBoyut.Items.Add("3x3");
            comboBoxBoyut.Items.Add("4x4");
            comboBoxBoyut.Items.Add("5x5");

            comboBoxBoyut.SelectedIndex = 0; // Varsayılan olarak ilk değeri seçer (3x3)
            labelSkor.Visible = false; // Skor başlangıçta gizlenir
        }

        // Başlat butonuna basıldığında bu kodu çalıştırır
        private void buttonBasla_Click(object sender, EventArgs e)
        {
            // Oyuncu adlarını ve oyun boyutunu alırız
            oyuncu1 = textBoxOyuncu1.Text;
            oyuncu2 = textBoxOyuncu2.Text;
            boyut = int.Parse(comboBoxBoyut.SelectedItem.ToString().Substring(0, 1));

            //burada giriş elemanlarını gizlenir
            textBoxOyuncu1.Visible = false;
            textBoxOyuncu2.Visible = false;
            comboBoxBoyut.Visible = false;
            buttonBasla.Visible = false;
            labelOyuncu1.Visible = false;
            labelOyuncu2.Visible = false;
            labelBoyut.Visible = false;

            // Skorları gösteririz
            labelSkor.Text = $"{oyuncu1} : {oyuncu1Skor}   /   {oyuncu2} : {oyuncu2Skor}";
            labelSkor.Visible = true;

            // Oyun alanını oluştururuz
            OyunAlaniOlustur();
        }

        // Oyun alanını oluştururuz
        private void OyunAlaniOlustur()
        {
            // Eski butonları temizleriz
            if (oyunButonlari != null)
            {
                foreach (var buton in oyunButonlari)
                    this.Controls.Remove(buton);
            }

            // Oyun butonlarını tanımlar ve yerleştiririz
            oyunButonlari = new Button[boyut, boyut];
            int butonBoyutu = 60; // Buton boyutunu ayarlarız
            int baslangicX = (this.ClientSize.Width - butonBoyutu * boyut) / 2; // X pozisyonunu merkezleriz
            int baslangicY = (this.ClientSize.Height - butonBoyutu * boyut) / 2; // Y pozisyonunu merkezleriz

            for (int i = 0; i < boyut; i++)
            {
                for (int j = 0; j < boyut; j++)
                {
                    Button buton = new Button();
                    buton.Size = new Size(butonBoyutu, butonBoyutu); // Buton boyutunu ayarlarız
                    buton.Location = new Point(baslangicX + j * butonBoyutu, baslangicY + i * butonBoyutu); // Konumunu ayarlarız
                    buton.Click += Buton_Click; // Butona tıklandığında Buton_Click metodunu çağırırız
                    buton.Font = new Font(FontFamily.GenericSansSerif, 20, FontStyle.Bold); // Yazı tipini ayarlıyormuş
                    oyunButonlari[i, j] = buton; // Butonu diziye ekleriz
                    this.Controls.Add(buton); // Butonu forma ekleriz
                }
            }
        }

        // Butona tıklandığında çalışır
        private void Buton_Click(object sender, EventArgs e)
        {
            Button buton = (Button)sender;
            if (buton.Text != "") return; // Eğer buton önceden işaretlenmişse işlem yapmayız

            // Sıradaki oyuncuya göre X veya O yazarız
            buton.Text = oyuncu1Sirada ? "X" : "O";
            oyuncu1Sirada = !oyuncu1Sirada; // Oyuncu sırasını değiştiririz

            // Kazananı kontrol ederiz
            if (KazananKontrol())
            {
                // Kazanan oyuncuyu bulur ve skoru güncelleriz
                string kazanan = oyuncu1Sirada ? oyuncu2 : oyuncu1;
                MessageBox.Show($"{kazanan} kazandı!");
                if (kazanan == oyuncu1) oyuncu1Skor++;
                else oyuncu2Skor++;

                // Skor etiketini güncelleriz
                labelSkor.Text = $"{oyuncu1} : {oyuncu1Skor}   /   {oyuncu2}  : {oyuncu2Skor}";

                // Yeni oyun başlatırız
                OyunAlaniOlustur();
            }
            else if (BerabereMi()) // Eğer oyun berabereyse
            {
                MessageBox.Show("Berabere!");
                OyunAlaniOlustur(); // Yeni oyun başlatırız
            }
        }

        // Kazanan olup olmadığını kontrol ederiz
        private bool KazananKontrol()
        {
            for (int i = 0; i < boyut; i++)
            {
                // Satır ve sütun kontrolü yaparız
                if (TumAyniMi(oyunButonlari[i, 0].Text, i, 0, 0, 1) || // Satır
                    TumAyniMi(oyunButonlari[0, i].Text, 0, i, 1, 0)) // Sütun
                    return true;
            }

            // Çaprazları kontrol ederiz
            return TumAyniMi(oyunButonlari[0, 0].Text, 0, 0, 1, 1) || // Sol üstten sağ alta
                   TumAyniMi(oyunButonlari[0, boyut - 1].Text, 0, boyut - 1, 1, -1); // Sağ üst
        }

        // Verilen x, y koordinatındaki buton ile belirtilen yönlerde (dx, dy) ilerleyerek 
        // tüm butonların aynı değeri (ilkDeger) taşıyıp taşımadığını kontrol eder.
        private bool TumAyniMi(string ilkDeger, int x, int y, int dx, int dy){

            // Eğer ilk buton boşsa, yani "X" veya "O" değilse, aynı değeri kontrol etmeye gerek yoktur.
            if (ilkDeger == "") return false;
            // Verilen yönde ilerleyerek her bir butonu kontrol ederiz.
            for (int i = 1; i < boyut; i++){

                // Eğer şu anki butonun değeri ilk butondan farklıysa, kazanan yok demektir.
                if (oyunButonlari[x + i * dx, y + i * dy].Text != ilkDeger)
                    return false;
            }
            // Eğer tüm butonlar aynı değeri taşıyorsa, kazanan bulunmuştur.
            return true;
        }


        // Tüm butonların dolu olup olmadığını kontrol eder.
        // Eğer bir tane boş buton varsa, oyun devam ediyordur.
        private bool BerabereMi()
        {
            foreach (var buton in oyunButonlari)
            {
                // Eğer boş bir buton varsa, berabere değildir.
                if (buton.Text == "")
                    return false;
            }

            // Eğer tüm butonlar doluysa, berabere olmuştur.
            return true;
        }
    }
}
