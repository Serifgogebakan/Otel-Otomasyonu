﻿namespace xox_oyun
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelOyuncu2 = new System.Windows.Forms.Label();
            this.labelOyuncu1 = new System.Windows.Forms.Label();
            this.textBoxOyuncu1 = new System.Windows.Forms.TextBox();
            this.textBoxOyuncu2 = new System.Windows.Forms.TextBox();
            this.buttonBasla = new System.Windows.Forms.Button();
            this.comboBoxBoyut = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelBoyut = new System.Windows.Forms.Label();
            this.labelSkor = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.SuspendLayout();
            // 
            // labelOyuncu2
            // 
            this.labelOyuncu2.AutoSize = true;
            this.labelOyuncu2.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelOyuncu2.Location = new System.Drawing.Point(12, 123);
            this.labelOyuncu2.Name = "labelOyuncu2";
            this.labelOyuncu2.Size = new System.Drawing.Size(154, 41);
            this.labelOyuncu2.TabIndex = 0;
            this.labelOyuncu2.Text = "2.Oyuncu :";
            // 
            // labelOyuncu1
            // 
            this.labelOyuncu1.AutoSize = true;
            this.labelOyuncu1.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelOyuncu1.Location = new System.Drawing.Point(12, 47);
            this.labelOyuncu1.Name = "labelOyuncu1";
            this.labelOyuncu1.Size = new System.Drawing.Size(150, 41);
            this.labelOyuncu1.TabIndex = 1;
            this.labelOyuncu1.Text = "1.Oyuncu :";
            // 
            // textBoxOyuncu1
            // 
            this.textBoxOyuncu1.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxOyuncu1.Location = new System.Drawing.Point(172, 47);
            this.textBoxOyuncu1.Name = "textBoxOyuncu1";
            this.textBoxOyuncu1.Size = new System.Drawing.Size(230, 48);
            this.textBoxOyuncu1.TabIndex = 2;
            // 
            // textBoxOyuncu2
            // 
            this.textBoxOyuncu2.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBoxOyuncu2.Location = new System.Drawing.Point(172, 123);
            this.textBoxOyuncu2.Name = "textBoxOyuncu2";
            this.textBoxOyuncu2.Size = new System.Drawing.Size(230, 48);
            this.textBoxOyuncu2.TabIndex = 3;
            // 
            // buttonBasla
            // 
            this.buttonBasla.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonBasla.Location = new System.Drawing.Point(282, 337);
            this.buttonBasla.Name = "buttonBasla";
            this.buttonBasla.Size = new System.Drawing.Size(218, 74);
            this.buttonBasla.TabIndex = 4;
            this.buttonBasla.Text = "Oyuna Başla";
            this.buttonBasla.UseVisualStyleBackColor = true;
            this.buttonBasla.Click += new System.EventHandler(this.buttonBasla_Click);
            // 
            // comboBoxBoyut
            // 
            this.comboBoxBoyut.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxBoyut.FormattingEnabled = true;
            this.comboBoxBoyut.Location = new System.Drawing.Point(483, 102);
            this.comboBoxBoyut.Name = "comboBoxBoyut";
            this.comboBoxBoyut.Size = new System.Drawing.Size(228, 49);
            this.comboBoxBoyut.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(12, 425);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(116, 127);
            this.panel1.TabIndex = 9;
            // 
            // labelBoyut
            // 
            this.labelBoyut.AutoSize = true;
            this.labelBoyut.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelBoyut.Location = new System.Drawing.Point(432, 47);
            this.labelBoyut.Name = "labelBoyut";
            this.labelBoyut.Size = new System.Drawing.Size(317, 41);
            this.labelBoyut.TabIndex = 10;
            this.labelBoyut.Text = "Harita Boyutu Seçiniz :";
            // 
            // labelSkor
            // 
            this.labelSkor.AutoSize = true;
            this.labelSkor.Font = new System.Drawing.Font("Impact", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelSkor.Location = new System.Drawing.Point(460, 510);
            this.labelSkor.Name = "labelSkor";
            this.labelSkor.Size = new System.Drawing.Size(193, 41);
            this.labelSkor.TabIndex = 11;
            this.labelSkor.Text = "Skor Tablosu";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(787, 25);
            this.toolStrip1.TabIndex = 12;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(787, 564);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.labelSkor);
            this.Controls.Add(this.labelBoyut);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.comboBoxBoyut);
            this.Controls.Add(this.buttonBasla);
            this.Controls.Add(this.textBoxOyuncu2);
            this.Controls.Add(this.textBoxOyuncu1);
            this.Controls.Add(this.labelOyuncu1);
            this.Controls.Add(this.labelOyuncu2);
            this.Name = "Form1";
            this.Text = "XoX";
            this.Click += new System.EventHandler(this.Buton_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelOyuncu2;
        private System.Windows.Forms.Label labelOyuncu1;
        private System.Windows.Forms.TextBox textBoxOyuncu1;
        private System.Windows.Forms.TextBox textBoxOyuncu2;
        private System.Windows.Forms.Button buttonBasla;
        private System.Windows.Forms.ComboBox comboBoxBoyut;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelBoyut;
        private System.Windows.Forms.Label labelSkor;
        private System.Windows.Forms.ToolStrip toolStrip1;
    }
}

