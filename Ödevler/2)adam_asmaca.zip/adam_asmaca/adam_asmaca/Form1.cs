﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adam_asmaca{
    public partial class proje : Form {

        public proje()
        {
            InitializeComponent();

        }
        String[] iller = {"ADANA", "ADIYAMAN", "AFYONKARAHISAR", "AĞRI", "AKSARAY", "AMASYA", "ANKARA", "ANTALYA", "ARDAHAN",
    "ARTVİN", "AYDIN", "BALIKESİR", "BARTIN", "BATMAN", "BAYBURT", "BİLECİK", "BİNGÖL", "BİTLİS", "BOLU",
    "BURDUR", "BURSA", "ÇANAKKALE", "ÇANKIRI", "ÇORUM", "DENIZLI", "DIYARBAKIR", "DÜZCE", "EDIRNE", "ELAZIĞ",
    "ERZİNCAN", "ERZURUM", "ESKİŞEHİR", "GAZİANTEP", "GİRESUN", "GÜMÜŞHANE", "HAKKARİ", "HATAY", "IĞDIR",             //// İllerin bulunduğu bir dizi 
    "ISPARTA", "İSTANBUL", "İZMIR", "KAHRAMANMARAŞ", "KARABÜK", "KARAMAN", "KARS", "KASTAMONU", "KAYSERİ",
    "KIRIKKALE", "KIRKLARELI", "KIRŞEHIR", "KILIS", "KOCAELI", "KONYA", "KÜTAHYA", "MALATYA", "MANİSA",
    "MARDIN", "MERSİN", "MUĞLA", "MUŞ", "NEVŞEHIR", "NİĞDE", "ORDU", "OSMANİYE", "RİZE", "SAKARYA", "SAMSUN",
    "ŞANLIURFA", "SİİRT", "SİNOP", "ŞIRNAK", "SIVAS", "TEKİRDAĞ", "TOKAT", "TRABZON", "TUNCELİ", "UŞAK",
    "VAN", "YALOVA", "YOZGAT","ZONGULDAK"};

        Random rand = new Random();                          // Rastgele bir il seçmek için kullanıyoruz

        // Oyun içi kullanılan değişkenler

        int index; 
        String random_il; // Rastgele seçilen il
        int hata_sayac = 0; // Hatalı sayacı

        private void Form1_Load(object sender, EventArgs e){  

            pictureBox1.Load("Resimler/" + hata_sayac + ".png");       //yaptığı hata numarasına göre resim gösteriyor 

            index =rand.Next(iller.Length);               //rastgele il seçiyor
            random_il = iller[index];                          

            for(int i=0 ; i<random_il.Length ; i++){           //Seçilen ile göre ekranda "_" çizgisi oluşturuyor

                lbl_text.Text += "_ ";           //her harf yerine bir çizgi koyuyor        
            }

        }

        private void Oyun(object sender, EventArgs e)              //harflere basınca bu olaylar gerçekleşiyor
        {
            Button secili_btn = sender as Button;        //tıkladığımız buton
            //MessageBox.Show(secili_btn.Text);
            secili_btn.Enabled = false;                  //butona bir kez bastıktan sonra devre dışı bırakıyor
            if (random_il.Contains(secili_btn.Text) == false)
            {
                hata_sayac++;
                pictureBox1.Load("Resimler/" + hata_sayac + ".png");              //resim değiştiriliyor
                lbl_kalan.Text = (6 - hata_sayac).ToString();             //kalan hakkımız yenileniyor  

            }
            else              //eğer doğruysa
            {
                String text = lbl_text.Text.Replace(" ", "");
                for (int i = 0; i < random_il.Length; i++)
                {
                    if (random_il[i].ToString() == secili_btn.Text)
                        text = ReplaceAt(text, i, 1, secili_btn.Text);           //doğru harfi yazar 


                }
                String sonuc = "";
                for (int i = 0; i < text.Length; i++)
                    sonuc += text[i].ToString() + " ";    //Alt çizgilerin ve harflerin arasına tekrar boşluklar eklener ekranda gösterir
                lbl_text.Text = sonuc;



                if (lbl_kalan.Text == "0")        // tüm haklar kullanılırsa oyun biter
                {

                    oyunubitir();                    //kaybetme
                }
                if (lbl_text.Text.Replace(" ", "") == random_il)      //tüm harfler doğru tahmin edildiyse oyun biter
                {
                    oyunubitir();                                      //kazanma

                }
            }
        }

        private void oyunubitir()  {       //oyun bitince çağrılan kısım

            if (lbl_kalan.Text == "0")
            {
                MessageBox.Show("Kaybettiniz! Doğru cevap: " + random_il, "Oyun Bitti", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (lbl_text.Text.Replace(" ", "") == random_il)
            {
                MessageBox.Show("Tebrikler, Kazandınız!", "Oyun Bitti", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }



        public static string ReplaceAt(string str, int index, int length, string replace)
            {
                return str.Remove(index, Math.Min(length, str.Length - index))              // Bir dizenin belirli bir kısmını değiştirmek için kullanılan fonksiyon
                          .Insert(index, replace);
            }

        private void lbl_kalan_Click(object sender, EventArgs e)
        {

        }
    }

    }
    
    

