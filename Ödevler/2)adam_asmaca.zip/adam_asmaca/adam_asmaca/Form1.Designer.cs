﻿namespace adam_asmaca
{
    partial class proje
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_text = new System.Windows.Forms.Label();
            this.Şehirler = new System.Windows.Forms.Label();
            this.lbl_kalan = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(26, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(403, 407);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_text
            // 
            this.lbl_text.AutoSize = true;
            this.lbl_text.BackColor = System.Drawing.Color.Transparent;
            this.lbl_text.Enabled = false;
            this.lbl_text.Font = new System.Drawing.Font("Impact", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_text.ForeColor = System.Drawing.Color.White;
            this.lbl_text.Location = new System.Drawing.Point(534, 129);
            this.lbl_text.Name = "lbl_text";
            this.lbl_text.Size = new System.Drawing.Size(0, 48);
            this.lbl_text.TabIndex = 32;
            // 
            // Şehirler
            // 
            this.Şehirler.AutoSize = true;
            this.Şehirler.BackColor = System.Drawing.Color.Transparent;
            this.Şehirler.Enabled = false;
            this.Şehirler.Font = new System.Drawing.Font("Impact", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Şehirler.ForeColor = System.Drawing.Color.White;
            this.Şehirler.Location = new System.Drawing.Point(454, 23);
            this.Şehirler.Name = "Şehirler";
            this.Şehirler.Size = new System.Drawing.Size(168, 48);
            this.Şehirler.TabIndex = 33;
            this.Şehirler.Text = "Şehirler ";
            // 
            // lbl_kalan
            // 
            this.lbl_kalan.AutoSize = true;
            this.lbl_kalan.BackColor = System.Drawing.Color.Transparent;
            this.lbl_kalan.Enabled = false;
            this.lbl_kalan.Font = new System.Drawing.Font("Impact", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_kalan.ForeColor = System.Drawing.Color.White;
            this.lbl_kalan.Location = new System.Drawing.Point(349, 495);
            this.lbl_kalan.Name = "lbl_kalan";
            this.lbl_kalan.Size = new System.Drawing.Size(51, 48);
            this.lbl_kalan.TabIndex = 34;
            this.lbl_kalan.Text = " 6";
            this.lbl_kalan.Click += new System.EventHandler(this.lbl_kalan_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(484, 314);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(69, 61);
            this.button1.TabIndex = 35;
            this.button1.Text = "E";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Oyun);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(559, 314);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(69, 61);
            this.button2.TabIndex = 36;
            this.button2.Text = "F";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Oyun);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(709, 314);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(69, 61);
            this.button3.TabIndex = 38;
            this.button3.Text = "Ğ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Oyun);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(634, 314);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(69, 61);
            this.button4.TabIndex = 37;
            this.button4.Text = "G";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Oyun);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(709, 381);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(69, 61);
            this.button5.TabIndex = 42;
            this.button5.Text = "L";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Oyun);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(634, 381);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(69, 61);
            this.button6.TabIndex = 41;
            this.button6.Text = "K";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Oyun);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(559, 381);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(69, 61);
            this.button7.TabIndex = 40;
            this.button7.Text = "J";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Oyun);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(484, 381);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(69, 61);
            this.button8.TabIndex = 39;
            this.button8.Text = "İ";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Oyun);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(709, 515);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(69, 61);
            this.button9.TabIndex = 50;
            this.button9.Text = "V";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.Oyun);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(634, 515);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(69, 61);
            this.button10.TabIndex = 49;
            this.button10.Text = "Ü";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.Oyun);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(559, 515);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(69, 61);
            this.button11.TabIndex = 48;
            this.button11.Text = "U";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.Oyun);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(484, 515);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(69, 61);
            this.button12.TabIndex = 47;
            this.button12.Text = "T";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.Oyun);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(709, 448);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(69, 61);
            this.button13.TabIndex = 46;
            this.button13.Text = "R";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.Oyun);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(634, 448);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(69, 61);
            this.button14.TabIndex = 45;
            this.button14.Text = "P";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.Oyun);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(559, 448);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(69, 61);
            this.button15.TabIndex = 44;
            this.button15.Text = "Ö";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.Oyun);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(484, 448);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(69, 61);
            this.button16.TabIndex = 43;
            this.button16.Text = "O";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.Oyun);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(784, 515);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(69, 61);
            this.button21.TabIndex = 62;
            this.button21.Text = "Y";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.Oyun);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(524, 247);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(69, 61);
            this.button22.TabIndex = 61;
            this.button22.Text = "A";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.Oyun);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(859, 448);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(69, 61);
            this.button23.TabIndex = 60;
            this.button23.Text = "Ş";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.Oyun);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(784, 448);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(69, 61);
            this.button24.TabIndex = 59;
            this.button24.Text = "S";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.Oyun);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(859, 515);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(69, 61);
            this.button25.TabIndex = 58;
            this.button25.Text = "Z";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.Oyun);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(674, 247);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(69, 61);
            this.button26.TabIndex = 57;
            this.button26.Text = "C";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.Oyun);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(859, 381);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(69, 61);
            this.button27.TabIndex = 56;
            this.button27.Text = "N";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.Oyun);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(784, 381);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(69, 61);
            this.button28.TabIndex = 55;
            this.button28.Text = "M";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.Oyun);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(599, 247);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(69, 61);
            this.button29.TabIndex = 54;
            this.button29.Text = "B";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.Oyun);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(749, 247);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(69, 61);
            this.button30.TabIndex = 53;
            this.button30.Text = "Ç";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.Oyun);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(859, 314);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(69, 61);
            this.button31.TabIndex = 52;
            this.button31.Text = "I";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.Oyun);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(784, 314);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(69, 61);
            this.button32.TabIndex = 51;
            this.button32.Text = "H";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.Oyun);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(824, 247);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(69, 61);
            this.button17.TabIndex = 63;
            this.button17.Text = "D";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.Oyun);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Impact", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(33, 495);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(288, 48);
            this.label1.TabIndex = 64;
            this.label1.Text = "Kalan Hakkınız :";
            // 
            // proje
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(995, 588);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbl_kalan);
            this.Controls.Add(this.Şehirler);
            this.Controls.Add(this.lbl_text);
            this.Controls.Add(this.pictureBox1);
            this.Name = "proje";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adam Asmaca";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_text;
        private System.Windows.Forms.Label Şehirler;
        private System.Windows.Forms.Label lbl_kalan;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label1;
    }
}

