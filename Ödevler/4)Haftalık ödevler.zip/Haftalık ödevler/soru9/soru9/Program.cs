﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru9{
    class Program{
        static void Main(){

            int boyut = 3; // Matris boyutu (NxN)
            int[,] enerjiMatrisi = RastgeleEnerjiMatrisiOlustur(boyut);

            // Rastgele oluşturulan enerji matrisini ekrana yazdır
            Console.WriteLine("Enerji Matrisi:");
            MatrisYazdir(enerjiMatrisi, boyut);

            // En az enerji harcanarak hedefe ulaşma
            int enAzEnerji = EnAzEnerjiYolu(enerjiMatrisi, boyut);

            Console.WriteLine("\nEn az enerji harcanarak varış noktasına ulaşmak için gereken enerji: " + enAzEnerji);
            Console.ReadLine();
        }

        // Rastgele enerji matrisi oluşturan fonksiyon
        static int[,] RastgeleEnerjiMatrisiOlustur(int boyut){

            int[,] matris = new int[boyut, boyut];
            Random random = new Random();

            for (int i = 0; i < boyut; i++){

                for (int j = 0; j < boyut; j++){

                    matris[i, j] = random.Next(1, 10); // 1 ile 9 arasında rastgele bir enerji değeri atar
                }
            }

            return matris;
        }

        // Enerji matrisini yazdırma fonksiyonu
        static void MatrisYazdir(int[,] matris, int boyut){

            for (int i = 0; i < boyut; i++){

                for (int j = 0; j < boyut; j++){

                    Console.Write(matris[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }

        // En az enerji harcanan yolu bulma fonksiyonu (Dinamik Programlama)
        static int EnAzEnerjiYolu(int[,] enerjiMatrisi, int boyut){

            // Minimum enerji maliyet matrisi oluşturma
            int[,] minEnerjiMaliyet = new int[boyut, boyut];

            // Başlangıç hücresinin maliyetini atama
            minEnerjiMaliyet[0, 0] = enerjiMatrisi[0, 0];

            // İlk satırın enerji maliyetlerini hesapla
            for (int j = 1; j < boyut; j++){

                minEnerjiMaliyet[0, j] = minEnerjiMaliyet[0, j - 1] + enerjiMatrisi[0, j];
            }

            // İlk sütunun enerji maliyetlerini hesapla
            for (int i = 1; i < boyut; i++){

                minEnerjiMaliyet[i, 0] = minEnerjiMaliyet[i - 1, 0] + enerjiMatrisi[i, 0];
            }

            // Kalan hücrelerin enerji maliyetlerini hesapla
            for (int i = 1; i < boyut; i++){

                for (int j = 1; j < boyut; j++){

                    int yukaridan = minEnerjiMaliyet[i - 1, j];
                    int soldan = minEnerjiMaliyet[i, j - 1];
                    int caprazdan = minEnerjiMaliyet[i - 1, j - 1];

                    // Minimum maliyeti seç ve mevcut hücre maliyetini ekle
                    minEnerjiMaliyet[i, j] = Math.Min(yukaridan, Math.Min(soldan, caprazdan)) + enerjiMatrisi[i, j];
                }
            }

            // Son hücredeki minimum enerji maliyeti en düşük maliyetle varış noktasına ulaşmamızı sağlar
            return minEnerjiMaliyet[boyut - 1, boyut - 1];
        }
    }
}
