﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru8{
    class Program{
        static void Main(){

            // Şifrelenecek mesajı kullanıcıdan alalım
            Console.Write("Şifrelenecek mesajı girin: ");
            string orijinalMesaj = Console.ReadLine();

            // Mesajı şifreleme işlemi
            string sifreliMesaj = Sifrele(orijinalMesaj);
            Console.WriteLine("\nŞifrelenmiş Mesaj: " + sifreliMesaj);

            // Şifreli mesajı çözme işlemi
            string cozulmusMesaj = SifreCoz(sifreliMesaj);
            Console.WriteLine("Çözülmüş Mesaj: " + cozulmusMesaj);
            Console.ReadLine();
        }

        // Fibonacci dizisi oluşturma
        static List<int> FibonacciDizisi(int n){

            List<int> fibonacci = new List<int> { 1, 1 };

            for (int i = 2; i < n; i++){

                fibonacci.Add(fibonacci[i - 1] + fibonacci[i - 2]);
            }
            return fibonacci;
        }

        // Pozisyonun asal olup olmadığını kontrol etme
        static bool AsalMi(int sayi){

            if (sayi <= 1)
                return false;
            for (int i = 2; i <= Math.Sqrt(sayi); i++){

                if (sayi % i == 0) return false;
            }
            return true;
        }

        // Şifreleme fonksiyonu
        static string Sifrele(string mesaj){

            int mesajUzunlugu = mesaj.Length;
            List<int> fibonacci = FibonacciDizisi(mesajUzunlugu);
            char[] sifreliMesaj = new char[mesajUzunlugu];

            for (int i = 0; i < mesajUzunlugu; i++){

                int asciiDegeri = (int)mesaj[i];
                int pozisyon = i + 1;
                int fibDeger = fibonacci[i];
                int sifrelenmisDeger;

                // Modüler çözümleme: Pozisyon asal mı?
                if (AsalMi(pozisyon)){

                    // Pozisyon asal ise, 100'e göre mod işlemi
                    sifrelenmisDeger = (asciiDegeri * fibDeger) % 100;
                }
                else{
                    // Pozisyon asal değilse, 256'ya göre mod işlemi
                    sifrelenmisDeger = (asciiDegeri * fibDeger) % 256;
                }

                // Şifrelenmiş değeri karaktere dönüştürme
                sifreliMesaj[i] = (char)sifrelenmisDeger;
            }

            return new string(sifreliMesaj);
        }

        // Şifre çözme fonksiyonu
        static string SifreCoz(string sifreliMesaj){
            int mesajUzunlugu = sifreliMesaj.Length;
            List<int> fibonacci = FibonacciDizisi(mesajUzunlugu);
            char[] orijinalMesaj = new char[mesajUzunlugu];

            for (int i = 0; i < mesajUzunlugu; i++){

                int sifreliAscii = (int)sifreliMesaj[i];
                int pozisyon = i + 1;
                int fibDeger = fibonacci[i];

                // Modüler çözümleme: Pozisyon asal mı?
                if (AsalMi(pozisyon)){

                    // Pozisyon asal ise, 100'e göre mod tersine alma
                    for (int k = 0; k < 256; k++){

                        if ((k * fibDeger) % 100 == sifreliAscii){

                            orijinalMesaj[i] = (char)k;
                            break;
                        }
                    }
                }
                else
                {
                    // Pozisyon asal değilse, 256'ya göre mod tersine alma
                    for (int k = 0; k < 256; k++){

                        if ((k * fibDeger) % 256 == sifreliAscii){

                            orijinalMesaj[i] = (char)k;
                            break;
                        }
                    }
                }
            }
            return new string(orijinalMesaj);
        }
    }
}
