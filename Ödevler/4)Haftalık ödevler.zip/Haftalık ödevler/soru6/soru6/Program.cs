﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru6
{
    class Program
    {
        static void Main()
        {
            // Geçerli tarihleri saklayacak bir liste oluşturuyoruz.
            List<string> gecerliTarihler = new List<string>();

            // Bugünün tarihini alıyoruz.
            DateTime bugun = DateTime.Now;

            // Başlangıç yılı olarak bugünün yılı veya 2000 yılını alıyoruz.
            int baslangicYili = Math.Max(bugun.Year, 2000);
            int bitisYili = 3000;

            // Yıl döngüsü: başlagıç yılından 3000 yılına kadar döngü
            for (int yil = baslangicYili; yil <= bitisYili; yil++)
            {
                // Yılın geçerli olup olmadığını kontrol et.
                if (!YilGecerliMi(yil)) continue;

                // Ay döngüsü: 1’den 12’ye kadar döner (Ocak'tan Aralık’a kadar)
                for (int ay = 1; ay <= 12; ay++)
                {
                    // Ayın geçerli olup olmadığını kontrol et.
                    if (!AyGecerliMi(ay)) continue;

                    // Belirli bir ayın kaç gün içerdiğini alıyoruz.
                    int aydakiGunSayisi = DateTime.DaysInMonth(yil, ay);

                    // Gün döngüsü: 1’den ayın son gününe kadar döner
                    for (int gun = 1; gun <= aydakiGunSayisi; gun++)
                    {
                        // Günün asal sayı olup olmadığını kontrol et.
                        if (!GunAsalMi(gun)) continue;

                        // Geçerli bir tarih oluşturuyoruz.
                        DateTime tarih = new DateTime(yil, ay, gun);

                        // Tarih bugünden büyükse, geçerli tarihler listesine ekle.
                        if (tarih > bugun)
                        {
                            gecerliTarihler.Add(tarih.ToString("dd/MM/yyyy"));
                        }
                    }
                }
            }

            // Geçerli tarihleri ekrana yazdır
            Console.WriteLine("Geçerli tarihler:");
            foreach (string tarih in gecerliTarihler)
            {
                Console.WriteLine(tarih);    
            }
            Console.ReadLine();
        }

        // Gün asal mı kontrolü: Sayı 2’den küçükse asal değildir, diğer durumlarda bölme kontrolü yaparız.
        static bool GunAsalMi(int gun)
        {
            if (gun < 2) return false;
            for (int i = 2; i * i <= gun; i++)
            {
                if (gun % i == 0) return false;
            }
            return true;
        }

        // Ay geçerliliği kontrolü: Ayın basamaklarının toplamı çift mi?
        static bool AyGecerliMi(int ay)
        {
            int basamakToplami = ay / 10 + ay % 10;
            return basamakToplami % 2 == 0;
        }

        // Yıl geçerliliği kontrolü: Yılın rakamlarının toplamı, yılın dörtte birinden küçük mü?
        static bool YilGecerliMi(int yil)
        {
            int rakamlarToplami = 0;
            int tempYil = yil;

            // Yılın rakamlarını topluyoruz.
            while (tempYil > 0)
            {
                rakamlarToplami += tempYil % 10;
                tempYil /= 10;
            }

            // Rakamlar toplamı yılın dörtte birinden küçükse geçerli.
            return rakamlarToplami < yil / 4;
        }
    }
}
