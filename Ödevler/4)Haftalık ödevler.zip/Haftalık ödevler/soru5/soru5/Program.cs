﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru5{
    class Program{
        static void Main(){

            while (true){

                // Kullanıcıdan birinci polinomu al
                Console.Write("Birinci polinomu girin (veya 'exit' yazarak çıkın): ");
                string polinom1 = Console.ReadLine();
                if (polinom1.ToLower() == "exit"){ // Çıkış kontrolü

                    Console.WriteLine("Programdan çıkılıyor...");
                    break; // Döngüden çık
                }

                // Kullanıcıdan ikinci polinomu al
                Console.Write("İkinci polinomu girin: ");
                string polinom2 = Console.ReadLine();

                // Polinomları toplama ve çıkarma işlemleri
                try{

                    var toplamaSonucu = PolinomTopla(polinom1, polinom2);
                    var cikarmaSonucu = PolinomCikar(polinom1, polinom2);

                    // Sonuçları ekrana yazdır
                    Console.WriteLine($"\nToplama Sonucu: {toplamaSonucu}");
                    Console.WriteLine($"Çıkarma Sonucu: {cikarmaSonucu}\n");
                }
                catch (Exception e){

                    Console.WriteLine($"Hata: {e.Message}. Lütfen geçerli bir polinom girin.");
                }
            }
            Console.ReadLine();
        }

        // Polinomları toplama işlemi
        static string PolinomTopla(string polinom1, string polinom2){

            var terimler1 = AyristirPolinom(polinom1);
            var terimler2 = AyristirPolinom(polinom2);
            var sonuc = BirleştirVeHesapla(terimler1, terimler2, true);
            return SonucBirleştir(sonuc);
        }

        // Polinomları çıkarma işlemi
        static string PolinomCikar(string polinom1, string polinom2){

            var terimler1 = AyristirPolinom(polinom1);
            var terimler2 = AyristirPolinom(polinom2);
            var sonuc = BirleştirVeHesapla(terimler1, terimler2, false);
            return SonucBirleştir(sonuc);
        }

        // Polinomu terimlerine ayırma
        static Dictionary<int, int> AyristirPolinom(string polinom){

            var terimler = new Dictionary<int, int>();
            var parcalar = polinom.Replace("-", "+-").Split('+');

            foreach (var terim in parcalar){

                if (string.IsNullOrWhiteSpace(terim)) continue; // Boş terimleri atla

                int katsayi = 1;
                int derece = 0;

                if (terim.Contains("x")){

                    var split = terim.Split('x');
                    if (split[0] != ""){

                        katsayi = int.Parse(split[0]);
                    }

                    if (split.Length > 1 && split[1].StartsWith("^")){

                        derece = int.Parse(split[1].Substring(1));
                    }
                    else{

                        derece = 1; // 'x' ifadesi için derece 1'dir
                    }
                }
                else{

                    katsayi = int.Parse(terim); // Sabit terim
                    derece = 0;
                }

                // Terimi sözlüğe ekle
                if (terimler.ContainsKey(derece)){

                    terimler[derece] += katsayi;
                }
                else{

                    terimler[derece] = katsayi;
                }
            }

            return terimler;
        }

        // Toplama veya çıkarma işlemi
        static Dictionary<int, int> BirleştirVeHesapla(Dictionary<int, int> terimler1, Dictionary<int, int> terimler2, bool toplama){

            var sonuc = new Dictionary<int, int>(terimler1);

            foreach (var terim in terimler2){

                if (toplama){

                    if (sonuc.ContainsKey(terim.Key)){

                        sonuc[terim.Key] += terim.Value;
                    }
                    else{

                        sonuc[terim.Key] = terim.Value;
                    }
                }
                else {// Çıkarma
              
                    if (sonuc.ContainsKey(terim.Key)){

                        sonuc[terim.Key] -= terim.Value;
                    }
                    else {

                        sonuc[terim.Key] = -terim.Value;
                    }
                }
            }

            return sonuc;
        }

        // Sonuç terimlerini birleştirip döndür
        static string SonucBirleştir(Dictionary<int, int> sonuc){

            var terimListesi = new List<string>();

            foreach (var terim in sonuc){

                if (terim.Value == 0) continue; // Katsayısı 0 olan terimleri atla

                if (terim.Key == 0){// Sabit terim

                    terimListesi.Add(terim.Value.ToString());
                }
                else if (terim.Key == 1) { // x terimi
                
                    terimListesi.Add(terim.Value == 1 ? "x" : $"{terim.Value}x");
                }
                else {// x^n terimi
                
                    terimListesi.Add(terim.Value == 1 ? $"x^{terim.Key}" : $"{terim.Value}x^{terim.Key}");
                }
            }

            return string.Join(" + ", terimListesi).Replace("+ -", "- ");
        }
    }
}
