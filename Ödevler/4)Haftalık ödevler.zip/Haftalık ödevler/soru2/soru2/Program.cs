﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru2{
    class Program{
        static void Main(){

            Console.Write("Kaç tane pozitif tam sayı olsun : ");
            int sayiAdedi = Convert.ToInt32(Console.ReadLine());

            List<int> sayilar = new List<int>(); // Sayıları saklamak için liste

            // Kullanıcıdan belirli sayıda pozitif tam sayıları alma
            for (int i = 0; i < sayiAdedi; i++){

                Console.Write($" {i + 1}.sayıyı gir: ");
                int girilenSayi = Convert.ToInt32(Console.ReadLine());

                while (girilenSayi <= 0) {        // Pozitif sayılar için kontrol
                
                    Console.WriteLine("pozitif bir tam sayı girin");
                    girilenSayi = Convert.ToInt32(Console.ReadLine());
                }

                sayilar.Add(girilenSayi); // Sayıyı listeye ekle
            }

            // Ortalamayı ve medyanı hesapla
            double ortalama = HesaplaOrtalama(sayilar);
            double medyan = HesaplaMedyan(sayilar);

            // Sonuçları yazdır
            Console.WriteLine($"\nOrtalama: {ortalama}");
            Console.WriteLine($"Medyan: {medyan}");
            Console.ReadLine();
        }

        static double HesaplaOrtalama(List<int> sayilar){
            double toplam = 0;

            foreach (var sayi in sayilar){

                toplam += sayi; // Toplama işlemi
            }

            return toplam / sayilar.Count; // Ortalama hesaplama
        }

        static double HesaplaMedyan(List<int> sayilar){

            sayilar.Sort(); // Sayıları sıralama

            int n = sayilar.Count;

            if (n % 2 == 0) { // Eğer çift sayıda eleman varsa
            
                // Ortanca iki sayının ortalaması
                return (sayilar[n / 2 - 1] + sayilar[n / 2]) / 2.0;
            }
            else{ // Tek sayıda eleman varsa

                return sayilar[n / 2]; // Ortanca elemanı döndür
            }
        }
    }
}
