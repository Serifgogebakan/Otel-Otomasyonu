﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru10
{
    class Program{
        static void Main(){

            // Sayı dizisi
            int[] sayilar = { 1, 9, 7, 5 };

            // Tüm operatörleri içeren dizi
            char[] operatorler = { '+', '-', '*', '/' };

            // Geçerli dizilimleri saklayacak liste
            List<string> gecerliDizilimler = new List<string>();

            // Tapınağın kapısını açmak için geçerli dizilimleri bulma
            GecerliDizilimleriBul(sayilar, operatorler, "", 0, gecerliDizilimler);

            // Geçerli dizilimleri ekrana yazdır
            Console.WriteLine("Geçerli dizilimler:");
            foreach (var dizilim in gecerliDizilimler){

                Console.WriteLine(dizilim);
                Console.ReadLine();
            }
        }

        // Geçerli dizilimleri bulan fonksiyon
        static void GecerliDizilimleriBul(int[] sayilar, char[] operatorler, string mevcutDizilim, int indeks, List<string> gecerliDizilimler){

            // Sayıların sonuna kadar geldiysek, geçerli olup olmadığını kontrol et
            if (indeks == sayilar.Length){

                if (IfadeDegerlendir(mevcutDizilim) > 0)  // Sonuç sıfırdan büyükse ekle
                    gecerliDizilimler.Add(mevcutDizilim);
                return;
            }

            // İlk sayıyı ekle
            if (indeks == 0){

                GecerliDizilimleriBul(sayilar, operatorler, sayilar[indeks].ToString(), indeks + 1, gecerliDizilimler);
            }
            else{

                // Tüm operatörler için kombinasyonları dene
                foreach (char op in operatorler){

                    // Yeni dizilimi oluştur
                    string yeniDizilim = mevcutDizilim + op + sayilar[indeks];

                    // Ara sonuç sıfırdan büyükse kombinasyonu devam ettir
                    if (IfadeDegerlendir(yeniDizilim) > 0){

                        GecerliDizilimleriBul(sayilar, operatorler, yeniDizilim, indeks + 1, gecerliDizilimler);

                    }
                }
            }
        }

        // Basit bir ifadeyi değerlendiren fonksiyon
        static double IfadeDegerlendir(string ifade){

            try{

                var dataTable = new System.Data.DataTable();
                return Convert.ToDouble(dataTable.Compute(ifade, ""));
            }
            catch{

                return double.MinValue; // Hata durumunda negatif bir değer döndür

            }
        }
    }
}