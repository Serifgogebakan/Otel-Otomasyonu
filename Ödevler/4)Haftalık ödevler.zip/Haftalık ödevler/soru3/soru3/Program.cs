﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru3{
    class Program{
        static void Main(){

            List<int> sayilar = new List<int>();
            Console.WriteLine("Bir dizi tamsayı girin (Çıkmak için 0 girin):");

            // Kullanıcıdan sayıları al
            while (true){

                int girilenSayi = Convert.ToInt32(Console.ReadLine());

                if (girilenSayi == 0){ // 0 girildiğinde döngüden çık
                    break;
                }
                sayilar.Add(girilenSayi); // Sayıyı listeye ekle
            }

            // Ardışık sayı gruplarını tespit et
            var ardisikGruplar = ArdışıkGruplariTespitEt(sayilar);

            // Sonuçları yazdır
            Console.WriteLine("Ardışık sayı grupları:");
            foreach (var grup in ardisikGruplar){
                Console.WriteLine(grup);
            }
            Console.ReadLine();
        }

        static List<string> ArdışıkGruplariTespitEt(List<int> sayilar){
            List<string> gruplar = new List<string>();

            if (sayilar.Count == 0){

                return gruplar; // Boş dizi için
            }

            // Sayıları sıralama
            sayilar.Sort();

            int baslangic = sayilar[0];
            int son = sayilar[0];

            for (int i = 1; i < sayilar.Count; i++){

                if (sayilar[i] == son + 1) { // Ardışık sayılar
                    son = sayilar[i]; // Ardışık sayıları güncelle
                }
                else{

                    // Grupları oluştur
                    if (baslangic == son){

                        gruplar.Add(baslangic.ToString()); // Tek sayıları ekle
                    }
                    else{

                        gruplar.Add($"{baslangic}-{son}"); // Grup aralığını ekle
                    }

                    // Yeni grup için başlangıç ve sonu güncelle
                    baslangic = sayilar[i];
                    son = sayilar[i];
                }
            }

            // Son grubu ekle
            if (baslangic == son){

          
                gruplar.Add(baslangic.ToString());
            }
            else{

                gruplar.Add($"{baslangic}-{son}");
            }

            return gruplar; // Tespit edilen grupları döndür
        }
    }
}
