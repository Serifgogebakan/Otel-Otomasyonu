﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace soru1{
    class Program{
        static void Main(){ 

            // Kullanıcıdan dizi boyutunu al
            Console.Write("Dizinin eleman sayısını girin: ");
            int n = int.Parse(Console.ReadLine());

            int[] numbers = new int[n];

            // Kullanıcıdan dizi elemanlarını al
            Console.WriteLine("Dizinin elemanlarını girin:");
            for (int i = 0; i < n; i++){

                Console.Write($"Eleman {i + 1}: ");
                numbers[i] = int.Parse(Console.ReadLine());
            }

            // Diziyi sıralama
            Array.Sort(numbers);
            Console.WriteLine("Sıralanmış dizi: " + string.Join(", ", numbers));

            // Kullanıcıdan aramak istediği sayıyı al
            Console.Write("Aramak istediğiniz sayıyı girin: ");
            int target = int.Parse(Console.ReadLine());

            // İkili arama algoritmasını kullanarak sayıyı bulma
            bool bulundu = IkiliArama(numbers, target);

            // Sonucu ekrana yazdır
            if (bulundu)
                Console.WriteLine("Sayı dizide mevcut.");
            else
                Console.WriteLine("Sayı dizide bulunamadı.");

            Console.ReadLine();
        }

        // İkili arama algoritması
        static bool IkiliArama(int[] dizi, int aranan){

            int sol = 0;
            int sag = dizi.Length - 1;

            // İkili arama işlemi
            while (sol <= sag){

                int orta = sol + (sag - sol) / 2;

                // Aranan sayı ortadaki elemana eşitse bulundu
                if (dizi[orta] == aranan)
                    return true;
                // Aranan sayı ortadaki elemandan büyükse sağ tarafa bak
                else if (dizi[orta] < aranan)
                    sol = orta + 1;
                // Aranan sayı ortadaki elemandan küçükse sol tarafa bak
                else
                    sag = orta - 1;
            }

            // Sayı bulunamadıysa false döndür
            return false;
        }
    }
}
