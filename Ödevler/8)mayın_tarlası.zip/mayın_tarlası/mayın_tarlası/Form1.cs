﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mayın_tarlası{
    public partial class Form1 : Form{
        private const int gridBoyutu = 15; // Grid boyutu
        private const int butonBoyutu = 30; // Butonların boyutu
        private Button[,] butonlar = new Button[gridBoyutu, gridBoyutu]; // Buton matrisi
        private int[,] mayinlar = new int[gridBoyutu, gridBoyutu]; // Mayın yerleşimi
        private bool[,] acilanHucreler = new bool[gridBoyutu, gridBoyutu]; // Açılmış hücreler
        private int toplamMayin = 30; // Toplam mayın sayısı

        public Form1() {
            InitializeComponent();

            mayın_tarlası_olusturucu();
            mayın_yerlestirme();        
        }

        // Grid oluşturan metod
        private void mayın_tarlası_olusturucu(){

            for (int satir = 0; satir < gridBoyutu; satir++){

                for (int sutun = 0; sutun < gridBoyutu; sutun++){

                    butonlar[satir, sutun] = new Button{

                        Size = new Size(butonBoyutu, butonBoyutu),
                        Location = new Point(sutun * butonBoyutu, satir * butonBoyutu),
                        Font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Bold),
                        Tag = new Point(satir, sutun) // Pozisyon bilgisini sakla

                    };
                    butonlar[satir, sutun].Click += ButonTikla; // Butona tıklama olayı ekle
                    this.Controls.Add(butonlar[satir, sutun]);
                }
            }
            this.ClientSize = new Size(gridBoyutu * butonBoyutu, gridBoyutu * butonBoyutu);
        }

        // Mayınları yerleştiren metod
        private void mayın_yerlestirme(){

            Random rastgele = new Random();
            int yerleşenMayinSayisi = 0;

            while (yerleşenMayinSayisi < toplamMayin){

                int x = rastgele.Next(gridBoyutu);
                int y = rastgele.Next(gridBoyutu);

                if (mayinlar[x, y] == 0) { // Eğer burada mayın yoksa        
                    mayinlar[x, y] = 1; // Mayın yerleştir
                    yerleşenMayinSayisi++;

                }
            }
        }

        // Butona tıklama işlemi
        private void ButonTikla(object sender, EventArgs e){

            Button tiklananButon = sender as Button;
            if (tiklananButon == null) return;

            Point pozisyon = (Point)tiklananButon.Tag;
            int x = pozisyon.X;
            int y = pozisyon.Y;

            if (mayinlar[x, y] == 1){

                tiklananButon.BackColor = Color.Red;
                MessageBox.Show("Mayına bastınız! Oyun sona erdi.");
                TumMayinlariGoster();

            }
            else {

                HucreyiAc(x, y);
                KazanmaKontrol();
            }
        }

        // Hücreyi açan metod
        private void HucreyiAc(int x, int y){

            if (x < 0 || y < 0 || x >= gridBoyutu || y >= gridBoyutu || acilanHucreler[x, y])
                return;

            acilanHucreler[x, y] = true;

            int cevreMayinSayisi = CevredekiMayinSayisi(x, y);
            butonlar[x, y].Text = cevreMayinSayisi == 0 ? "" : cevreMayinSayisi.ToString();
            butonlar[x, y].BackColor = Color.LightGray;

            if (cevreMayinSayisi == 0){

                // Çevredeki hücreleri de aç
                for (int i = -1; i <= 1; i++){

                    for (int j = -1; j <= 1; j++){

                        HucreyiAc(x + i, y + j);

                    }
                }
            }
        }

        // Çevredeki mayın sayısını bulan metod
        private int CevredekiMayinSayisi(int x, int y){

            int sayac = 0;
            for (int i = -1; i <= 1; i++){

                for (int j = -1; j <= 1; j++){

                    int nx = x + i;
                    int ny = y + j;
                    if (nx >= 0 && ny >= 0 && nx < gridBoyutu && ny < gridBoyutu){

                        sayac += mayinlar[nx, ny];
                    }
                }
            }
            return sayac;
        }

        // Tüm mayınları gösteren metod
        private void TumMayinlariGoster(){

            for (int satir = 0; satir < gridBoyutu; satir++){

                for (int sutun = 0; sutun < gridBoyutu; sutun++){

                    if (mayinlar[satir, sutun] == 1){

                        butonlar[satir, sutun].BackColor = Color.Red;
                        butonlar[satir, sutun].Text = "M";
                    }
                    else{

                        int cevreMayinSayisi = CevredekiMayinSayisi(satir, sutun);
                        butonlar[satir, sutun].Text = cevreMayinSayisi == 0 ? "" : cevreMayinSayisi.ToString();
                        butonlar[satir, sutun].BackColor = Color.LightGray;

                    }
                }
            }
        }

        // Kazanma durumunu kontrol eden metod
        private void KazanmaKontrol(){

            int açılmışHucreSayisi = 0;
            for (int satir = 0; satir < gridBoyutu; satir++){

                for (int sutun = 0; sutun < gridBoyutu; sutun++){

                    if (acilanHucreler[satir, sutun]) açılmışHucreSayisi++;
                }
            }

            if (açılmışHucreSayisi == gridBoyutu * gridBoyutu - toplamMayin){

                MessageBox.Show("Tebrikler! Tüm mayınsız hücreleri açtınız!");
                TumMayinlariGoster();

            }
        }

    }
}
