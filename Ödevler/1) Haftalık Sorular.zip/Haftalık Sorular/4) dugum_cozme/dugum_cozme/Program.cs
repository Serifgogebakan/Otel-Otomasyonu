﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dugum_cozme
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Grid genişliğini girin (N x N): ");
            int N = int.Parse(Console.ReadLine());


            int[,] grid = GridOlustur(N);
            Console.WriteLine("Oluşturulan Map:");
            GridGoster(grid, N);


            List<(int, int)> robotBaslangic = new List<(int, int)>();                //baslama noktası belirlemek için kullanıcıdan veri alırız

            for (int i = 0; i < 3; i++) // 3 robot
            {
                Console.WriteLine($"Robot {i + 1} için başlangıç pozisyonunu girin (satır, sütun): ");
                string[] pos = Console.ReadLine().Split(',');
                int satir = int.Parse(pos[0]);
                int sutun = int.Parse(pos[1]);
                robotBaslangic.Add((satir, sutun));
            }

            int toplamKurtarilanDugum = KurtarilanDugumleriHesapla(grid, robotBaslangic);
            Console.WriteLine("Toplam Kurtarılan Düğüm Sayısı: {toplamKurtarilanDugum}");
        }


        static int[,] GridOlustur(int N)
        {
            Random rand = new Random();
            int[,] grid = new int[N, N];
            //  rastgele bir harita oluşturur
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    grid[i, j] = rand.Next(0, 2); // 0 veya 1
                }
            }

            return grid;
        }


        static void GridGoster(int[,] grid, int N)
        {
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)                 //haritayı göstermemizi sağlar
                {
                    Console.Write(grid[i, j] + " ");
                }
                Console.WriteLine();
            }
        }


        static int KurtarilanDugumleriHesapla(int[,] grid, List<(int, int)> robotBaslangic)
        {
            int N = grid.GetLength(0);
            HashSet<(int, int)> kurtarilanDugumler = new HashSet<(int, int)>();
            int[] dX = { -1, 1, 0, 0 }; // Yukarı, Aşağı, Sola, Sağa
            int[] dY = { 0, 0, -1, 1 };

            foreach (var baslangic in robotBaslangic)
            {
                int baslangicX = baslangic.Item1;
                int baslangicY = baslangic.Item2;                       //Dügme hesabı yapılan kısım



                if (baslangicX >= 0 && baslangicX < N && baslangicY >= 0 && baslangicY < N && grid[baslangicX, baslangicY] == 1)
                {
                    DFS(grid, baslangicX, baslangicY, kurtarilanDugumler, dX, dY);
                }
            }

            return kurtarilanDugumler.Count;
        }
    }
}

       
     