﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asalsayı_toplam{
    class Program{
        static void Main(string[] args){

            int toplam = 0;


            Console.WriteLine(" Bir N sayısı giriniz : ");
            int sayı = int.Parse(Console.ReadLine());


            for (int i = 2; i < sayı; i++){
                if (asalbulma(i)){
                    toplam += i;
                }   
            }

            Console.WriteLine(sayı + " 'e kadar olan Asal sayılar toplamı : " + toplam);
            Console.ReadLine();
        }




        static bool asalbulma (int a){

            for (int i = 2; i <= Math.Sqrt(a); i++){
                if (a % i == 0)
                    return false;
             }
                return true;
        }



    }
}
