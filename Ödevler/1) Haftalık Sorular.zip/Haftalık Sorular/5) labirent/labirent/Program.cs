﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labirent{
    class Program{ 
        public static void Main(String[] args){

            Console.WriteLine("Labirent genişliği kaç olsun : ");
            int N = int.Parse(Console.ReadLine());


            int[,] maze = Labirentoluşturma(N);

            Labirentgoster(N,maze);

            Console.ReadLine();
         }




         static void Labirentoluşturma(int N){
            Random rand = new Random();
            int[,] maze = new int[N,N];

            for (int i = 0; i<N; i++){
                for(int j =0 ; j<N ; j++){

                    maze[i, j] = rand.Next(0, 2);
                }
            }
            maze[0, 0] = 1;      //baslangıc
            maze[N-1, N-1] = 1;  //bitis
        }


        static void Labirentgoster(int N , int[,] maze)
        {

            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++){
                    Console.WriteLine(maze[i,j] + " ");
                }
                Console.WriteLine();
            }
        }

        static string EnKisaYol(int[,] labirent, int N)
        {
            // Yön vektörleri (yukarı, aşağı, sol, sağ)
            int[] dx = { -1, 1, 0, 0 };
            int[] dy = { 0, 0, -1, 1 };

            // Kuyruk ve ziyaret edilenler kümesi
            Queue<(int, int, int)> kuyruk = new Queue<(int, int, int)>();
            bool[,] ziyaretEdilen = new bool[N, N];

            // Başlangıç noktasını kuyruğa ekle
            kuyruk.Enqueue((0, 0, 1)); // (x, y, adım sayısı)
            ziyaretEdilen[0, 0] = true;

            // Eğer başlangıç ya da bitiş geçerli değilse
            if (labirent[0, 0] == 0 || labirent[N - 1, N - 1] == 0)
            {
                return "Yol Yok";
            }

            // BFS döngüsü
            while (kuyruk.Count > 0)
            {
                var (x, y, adim) = kuyruk.Dequeue();

                // Hazineye ulaştık mı?
                if (x == N - 1 && y == N - 1)
                {
                    return $"En Kısa Yol: {adim} adım";
                }

                // 4 yöne hareket et
                for (int i = 0; i < N; i++)
                {
                    int nx = x + dx[i];
                    int ny = y + dy[i];

                    // Sınırlar içinde mi ve geçerli bir yol mu?
                    if (nx >= 0 && nx < N && ny >= 0 && ny < N && labirent[nx, ny] == 1 && !ziyaretEdilen[nx, ny])
                    {
                        kuyruk.Enqueue((nx, ny, adim + 1));
                        ziyaretEdilen[nx, ny] = true;
                    }
                }
            }

            return "Yol Yok"; // Hazineye ulaşılamadıysa
        }

    }
    }
