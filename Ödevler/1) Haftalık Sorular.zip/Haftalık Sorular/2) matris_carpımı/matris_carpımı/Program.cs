﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace matris_carpımı
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine(" Matris çarpımı için Bir N sayısı Giriniz : ");
            int n = int.Parse(Console.ReadLine());                                    //Burada Matris Boyutu ayarlanır


            int[,] ilk_matris = new int[n, n];
            Console.WriteLine("Birinci matrisin elemanlarını giriniz : ");
            for (int i = 0; i < n; i++){
                for (int j = 0; j < n; j++) {                                       //Burada 1. matrise elemanlar yerleştirilir 
                    Console.WriteLine("matris [" + i + " " + j + "] :");
                    ilk_matris[i, j] = int.Parse(Console.ReadLine());
                }
            }



            int[,] ikinci_matris = new int[n, n];
            Console.WriteLine("İkinci matrisin elemanlarını giriniz : ");
            for (int i = 0; i < n; i++){
                for (int j = 0; j < n; j++){
                    Console.WriteLine("matris [" + i + " " + j + "] :");
                    ilk_matris[i, j] = int.Parse(Console.ReadLine());
                }
            }



            int[,] carpım = new int[n, n];
            for (int i = 0; i < n; i++){
                for (int j = 0; j < n; j++) {
                                                                                     //matrislerin çerpıldığı kısım                                           
                    for (int k = 0; k < n; k++){

                        carpım[i, j] += ilk_matris[i, k] * ikinci_matris[k, j]; //burası matris işleminin yapıldığı yer 
                    }
                }
            }


            Console.WriteLine("Matrislerin çarpımlarlının sonucu:");
            for (int i = 0; i < n; i++){
                for (int j = 0; j < n; j++){                               //çıktıları ekrana yazan kısım
                    Console.Write(carpım[i, j] + "     ");
                }
                Console.WriteLine(); //alt satıra geçer
            }


            Console.ReadLine();         //bu olmazsa konsol ekranı hemen kapanıyor
        }
    }
}
