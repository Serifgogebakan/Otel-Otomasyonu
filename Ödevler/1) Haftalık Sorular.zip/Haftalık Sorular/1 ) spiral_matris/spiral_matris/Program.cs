﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace spiral_matris{
    class Program{
        
            static void Main(string[] args){
                Console.Write("spiral (NxN) boyutu için sayı giriniz : ");
                int n = int.Parse(Console.ReadLine());                         //burada kullanıcıdan boyut alıyoruz   

                int[,] matris = new int[n, n];                                //kullanıcıdan aldığımız parametreye göre çif boyutlu dizi oluşturur

                SpiralMatrisDoldur(matris, n);
                MatrisYazdir(matris, n);                                     //ekrana yazdırır
                Console.ReadLine();
            }

            static void SpiralMatrisDoldur(int[,] matris, int a){
                int sayi = 1;
                int sol = 0, sag = a - 1, yukari = 0, asagi = a - 1;

                while (sayi <= a * a){
                              
                    for (int i = sol; i <= sag; i++){                
                        matris[yukari, i] = sayi++;               //dizide sola doğru gider
                    }
                    yukari++;

                    
                    for (int i = yukari; i <= asagi; i++){
                        matris[i, sag] = sayi++;                 //sağdan en aşağı doğru
                    }
                    sag--;

                    
                    for (int i = sag; i >= sol; i--){    
                        matris[asagi, i] = sayi++;                 //dizide sağa gider
                }
                    asagi--;

                    
                    for (int i = asagi; i >= yukari; i--){         //yukarı doğru gider 
                        matris[i, sol] = sayi++;
                    }
                    sol++;
                }
            }

            static void MatrisYazdir(int[,] matris, int n){
                for (int i = 0; i < n; i++){
                    for (int j = 0; j < n; j++){                  //ekrana yazmamızı sağlayan metot
                        Console.Write(matris[i, j]+"     ");
                    }
                    Console.WriteLine();   //yeni satıra geçmeyi sağlar
                }
            }

        }

    }


