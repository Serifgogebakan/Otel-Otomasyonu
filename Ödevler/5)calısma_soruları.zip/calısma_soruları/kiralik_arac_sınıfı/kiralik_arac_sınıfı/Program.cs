﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kiralik_arac_sınıfı
{
    public class KiralikArac
    {

        // Araç bilgileri
        public string Plaka { get; private set; }
        public decimal GunlukUcret { get; private set; }
        public bool MusaitMi { get; private set; } // Araç uygunluk durumu

        // Yapıcı Metot araç plakası ve günlük ücreti alarak sınıfı başlatılır
        public KiralikArac(string plaka, decimal gunlukUcret){

            Plaka = plaka;
            GunlukUcret = gunlukUcret;
            MusaitMi = true; // Varsayılan olarak aracı müsait olarak ayarlar
        }

        // Araç kiralama metodu
        public void AraciKirala(){

            if (MusaitMi){

                MusaitMi = false; // Aracı kiralandı olarak işaretle
                Console.WriteLine($"{Plaka} plakalı araç kiralandı.");
            }
            else{

                Console.WriteLine($"{Plaka} plakalı araç zaten kirada.");
            }
        }

        // Aracı teslim etme metodu
        public void AraciTeslimEt(){

            if (!MusaitMi){

                MusaitMi = true; // Aracı müsait olarak işaretle
                Console.WriteLine($"{Plaka} plakalı araç teslim edildi.");
            }

            else{

                Console.WriteLine($"{Plaka} plakalı araç zaten müsait.");
            }
        }

        // Main metodu: Sınıfın işleyişini test eder
        public static void Main(string[] args){

            var arac = new KiralikArac("23YMT2024", 200); // Yeni bir araç oluştur
            arac.AraciKirala(); // Aracı kirala
            arac.AraciTeslimEt(); // Aracı teslim et

            Console.ReadLine();
        }

    }
}
