﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace urun_sınıfı{
    public class Urun {
        // Ürünün adı ve fiyatı
        public string Ad { get; private set; }
        public decimal Fiyat { get; private set; }

        private decimal indirim; // İndirim yüzdesi ayarlanır

        // İndirimi ayarlamak için get ve set metotları
        public decimal Indirim{

            get {

                return indirim;
            }

            set{
                // İndirimi 0 ile 50 arasında sınırlar
                if (value >= 0 && value <= 50){

                    indirim = value;
                }
                else{

                    Console.WriteLine("İndirim değeri 0 ile 50 arasında olmalıdır.");
                }
            }
        }

        // Yapıcı Metot: Ürün adı ve fiyatı ile sınıfı başlatır
        public Urun(string ad, decimal fiyat){

            Ad = ad;
            Fiyat = fiyat;
            indirim = 0; // Varsayılan indirim %0
        }

        // İndirimli fiyatı hesaplayan metot
        public decimal IndirimliFiyat(){

            return Fiyat * (1 - (indirim / 100));
        }

        public static void Main(string[] args){

            var urun = new Urun("Laptop", 20000); // Yeni bir ürün oluşturur
            urun.Indirim = 20; // İndirimi %20 olarak ayarlar
            Console.WriteLine($"Ürün: {urun.Ad}, İndirimli Fiyat: {urun.IndirimliFiyat():C}"); // İndirimli fiyatı gösterir

            urun.Indirim = 60; // Geçersiz bir indirim dener
            Console.ReadLine();

        }
    }
}
