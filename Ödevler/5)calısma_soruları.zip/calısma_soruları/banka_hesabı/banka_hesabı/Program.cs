﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace banka_hesabı{
    public class BankaHesabi{

        // Özellikler
        public string HesapNumarasi { get; private set; } // Hesap numarası sadece okunabilir
        private decimal bakiye; // Bakiye yalnızca sınıf içinde değiştirilebilir

        // Bakiye özelliği için yalnızca okunabilir bir get metodu
        public decimal Bakiye{

            get { return bakiye; }
        }

        // Yapıcı Metot: Hesap numarası ve başlangıç bakiyesini alarak sınıfı başlatır
        public BankaHesabi(string hesapNumarasi, decimal ilkBakiye) {

            HesapNumarasi = hesapNumarasi;
            bakiye = ilkBakiye; // Başlangıç bakiyesini ayarlar
        }

        // Para yatırma metodu: Pozitif miktarları hesaba ekler
        public void ParaYatir(decimal miktar){

            if (miktar > 0){

                bakiye += miktar;
                Console.WriteLine($"Hesabınıza {miktar:C} yatırıldı. Güncel bakiye: {bakiye:C}");
            }
        }

        // Para çekme metodu: Pozitif miktarları hesaptan çeker. Yetersiz bakiye kontrolü yapılır
        public void ParaCek(decimal miktar){

            if (miktar > 0 && miktar <= bakiye){

                bakiye -= miktar;
                Console.WriteLine($"Hesabınızdan {miktar:C} çekildi. Güncel bakiye: {bakiye:C}");
            }
            else{

                Console.WriteLine("Yetersiz bakiye veya geçersiz işlem.");
            }
        }

        // Main metodu: Sınıfın işleyişini test eder
        public static void Main(string[] args) {

            var hesap = new BankaHesabi("YMT_LAB", 1000); // Yeni bir hesap oluştur
            hesap.ParaYatir(500); // 500 birim para yatır
            hesap.ParaCek(300); // 300 birim para çek
            hesap.ParaCek(1500); // Yetersiz bakiye örneği
        }
    }
}
