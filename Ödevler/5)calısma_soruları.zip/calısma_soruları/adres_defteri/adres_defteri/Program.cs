﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adres_defteri{
    public class Kisi { 

        // Kişi bilgileriri
        public string Ad { get; private set; }
        public string Soyad { get; private set; }
        public string TelefonNumarasi { get; private set; }

        // Yapıcı Metot kişinin adı, soyadı ve numarası ile sınıfı başlatır
        public Kisi(string ad, string soyad, string telefonNumarasi){

            Ad = ad;
            Soyad = soyad;
            TelefonNumarasi = telefonNumarasi;
        }

        // Kişi bilgilerini döndüren metot
        public string KisiBilgisi() {

            return $"{Ad} {Soyad} - Telefon No : {TelefonNumarasi}";
        }

        // Main metodu sınıfın işleyişini test eder
        public static void Main(string[] args){

            var kisi = new Kisi("Hüseyin", "Hoca", "0111 111 11 11"); // Yeni bir kişi oluştur
            Console.WriteLine(kisi.KisiBilgisi()); // Kişi bilgilerini yazdır

            Console.ReadLine();
        }
    }
}
