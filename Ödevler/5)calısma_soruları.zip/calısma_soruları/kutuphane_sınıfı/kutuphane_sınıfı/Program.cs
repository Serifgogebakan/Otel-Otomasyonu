﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kutuphane_sınıfı{
    public class Kitap{
        public string Ad { get; private set; }
        public string Yazar { get; private set; }

        // Yapıcı Metot 
        public Kitap(string ad, string yazar){

            Ad = ad;
            Yazar = yazar;
        }

        // Kitap bilgilerini ekrana yazdıran metot
        public void BilgileriYazdir(){

            Console.WriteLine($"Adı: {Ad} - Yazarı: {Yazar}");
           
        }
    }

    public class Kutuphane{

        // Kitap listesi eklenen kitapların verileri burada tutulur
        private List<Kitap> Kitaplar { get; set; }

        // Yapıcı Metot kitap listesini boş olarak başlatır
        public Kutuphane(){

            Kitaplar = new List<Kitap>();
        }

        // Yeni kitap ekleme metodu
        public void KitapEkle(Kitap yeniKitap){

            Kitaplar.Add(yeniKitap);

            Console.Write("Kitap eklendi:    ");
            yeniKitap.BilgileriYazdir(); // Yeni eklenen kitabı yazdırır

        }

        // Kütüphanedeki tüm kitapları listeleyen metot
        public void KitaplariListele(){

            Console.WriteLine(); // boşluk bırakmak için
            Console.WriteLine("Kütüphanedeki kitaplar:");
            Console.WriteLine();

            foreach (var kitap in Kitaplar){

                kitap.BilgileriYazdir(); // Her kitabın bilgilerini yazdırır
            }
        }
    }

    public class Program{
        public static void Main(string[] args){

            var kutuphane = new Kutuphane(); // Yeni bir kütüphane nesnesi oluşturur

            kutuphane.KitapEkle(new Kitap("Simyacı", "Paulo Coelho")); // Kütüphaneye kitap ekler
            kutuphane.KitapEkle(new Kitap("1984", "George Orwell"));   // Bir kitap daha ekler  

            kutuphane.KitaplariListele(); // Eklenen kitapları listeler

            Console.ReadLine(); // Kullanıcının bir tuşa basmasını bekler
        }
    }
}