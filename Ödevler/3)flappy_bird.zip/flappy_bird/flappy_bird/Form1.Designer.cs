﻿namespace flappy_bird
{
    partial class Flappy_Bird_Game
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Flappy_Bird_Game));
            this.Bird = new System.Windows.Forms.PictureBox();
            this.üst_sütun = new System.Windows.Forms.PictureBox();
            this.alt_sütun = new System.Windows.Forms.PictureBox();
            this.Scoreboard = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ground = new System.Windows.Forms.PictureBox();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.ground2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Bird)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.üst_sütun)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.alt_sütun)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground2)).BeginInit();
            this.SuspendLayout();
            // 
            // Bird
            // 
            this.Bird.BackColor = System.Drawing.Color.Transparent;
            this.Bird.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Bird.BackgroundImage")));
            this.Bird.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Bird.Location = new System.Drawing.Point(82, 188);
            this.Bird.Name = "Bird";
            this.Bird.Size = new System.Drawing.Size(57, 50);
            this.Bird.TabIndex = 1;
            this.Bird.TabStop = false;
            // 
            // üst_sütun
            // 
            this.üst_sütun.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("üst_sütun.BackgroundImage")));
            this.üst_sütun.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.üst_sütun.Location = new System.Drawing.Point(515, -31);
            this.üst_sütun.Name = "üst_sütun";
            this.üst_sütun.Size = new System.Drawing.Size(67, 196);
            this.üst_sütun.TabIndex = 2;
            this.üst_sütun.TabStop = false;
            // 
            // alt_sütun
            // 
            this.alt_sütun.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("alt_sütun.BackgroundImage")));
            this.alt_sütun.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.alt_sütun.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.alt_sütun.Location = new System.Drawing.Point(515, 302);
            this.alt_sütun.Name = "alt_sütun";
            this.alt_sütun.Size = new System.Drawing.Size(67, 205);
            this.alt_sütun.TabIndex = 3;
            this.alt_sütun.TabStop = false;
            // 
            // Scoreboard
            // 
            this.Scoreboard.AutoSize = true;
            this.Scoreboard.BackColor = System.Drawing.Color.Khaki;
            this.Scoreboard.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Scoreboard.Location = new System.Drawing.Point(12, 457);
            this.Scoreboard.Name = "Scoreboard";
            this.Scoreboard.Size = new System.Drawing.Size(127, 37);
            this.Scoreboard.TabIndex = 4;
            this.Scoreboard.Text = "Skor : 0";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ground
            // 
            this.ground.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ground.BackgroundImage")));
            this.ground.Location = new System.Drawing.Point(-30, 440);
            this.ground.Name = "ground";
            this.ground.Size = new System.Drawing.Size(805, 95);
            this.ground.TabIndex = 5;
            this.ground.TabStop = false;
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // ground2
            // 
            this.ground2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ground2.BackgroundImage")));
            this.ground2.Location = new System.Drawing.Point(-17, -84);
            this.ground2.Name = "ground2";
            this.ground2.Size = new System.Drawing.Size(805, 95);
            this.ground2.TabIndex = 6;
            this.ground2.TabStop = false;
            // 
            // Flappy_Bird_Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(762, 503);
            this.Controls.Add(this.Scoreboard);
            this.Controls.Add(this.ground);
            this.Controls.Add(this.alt_sütun);
            this.Controls.Add(this.üst_sütun);
            this.Controls.Add(this.Bird);
            this.Controls.Add(this.ground2);
            this.Name = "Flappy_Bird_Game";
            this.Text = "Flappy Bird";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Flappy_Bird_Game_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Flappy_Bird_Game_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.Bird)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.üst_sütun)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.alt_sütun)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ground2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Bird;
        private System.Windows.Forms.PictureBox üst_sütun;
        private System.Windows.Forms.PictureBox alt_sütun;
        private System.Windows.Forms.Label Scoreboard;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox ground;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.PictureBox ground2;
    }
}

