﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace flappy_bird{
    public partial class Flappy_Bird_Game : Form{

        // Oyun hızını belirleyen değişken
        int hiz = 8;

        // Yerçekimi etkisini belirleyen değişken
        int yercekimi = 15;

        // Skor değişkeni
        int skor = 0;

        public Flappy_Bird_Game(){  //kurucu metot
            // Formun bileşenlerini başlatır
            InitializeComponent();
        }

        // Oyun zamanlayıcısının her tick olayında çalışır
        private void timer1_Tick(object sender, EventArgs e){

            // Kuşun yukarı veya aşağı hareket etmesi için yerçekimi eklenir
            Bird.Top += yercekimi;

            // Üst ve alt sütunların sola doğru hareket etmesi
            üst_sütun.Left -= hiz;
            alt_sütun.Left -= hiz;

            // Skor tahtasına güncel skor yazılır
            Scoreboard.Text = "Skor : " + skor;

            // Üst sütun ekranın soluna ulaştığında yeniden konumlandırılır ve skor artırılır
            if (üst_sütun.Left < -150){
                üst_sütun.Left = 500;
                skor++;
            }

            // Alt sütun ekranın soluna ulaştığında yeniden konumlandırılır
            if (alt_sütun.Left < -150){
                alt_sütun.Left = 500;
            }

            // Kuşun sütunlara veya yere çarpması durumu
            if (Bird.Bounds.IntersectsWith(üst_sütun.Bounds) ||
               Bird.Bounds.IntersectsWith(alt_sütun.Bounds) ||
               Bird.Bounds.IntersectsWith(ground.Bounds) ||
               Bird.Bounds.IntersectsWith(ground2.Bounds)){

                // Çarpışma durumunda oyunu sonlandırır
                oyunbitti();
            }
        }

        // Kullanıcı "Space" tuşuna bastığında kuşun yukarı hareket etmesi için yerçekimi ters çevrilir
        private void Flappy_Bird_Game_KeyDown(object sender, KeyEventArgs e){
            if (e.KeyCode == Keys.Space)
                yercekimi = -15;
        }

        // Kullanıcı "Space" tuşunu bıraktığında yerçekimi normale döner
        private void Flappy_Bird_Game_KeyUp(object sender, KeyEventArgs e){
            if (e.KeyCode == Keys.Space)
                yercekimi = 15;
        }

        // Oyunun bittiği durumlarda çalışan fonksiyon
        private void oyunbitti(){
            // Zamanlayıcı durdurulur ve oyun bitti mesajı gösterilir
            timer1.Stop();
            Scoreboard.Text = "Oyun Bitti !!!";

        }
    }
}